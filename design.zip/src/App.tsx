import DemoPage from "@/components/ui/demo"

export default function App() {
  return (
    <div className="w-full min-h-screen">
      <DemoPage />
    </div>
  )
}
