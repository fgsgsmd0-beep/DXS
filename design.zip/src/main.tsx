import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import './perf.css'
import App from './App.tsx'
import { initSmoothWheel } from './lib/smooth-wheel'

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
)

// Register the Service Worker that keeps the video cached in the visitor's browser
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch(() => {})

  })
}

// PC only: soft eased mouse-wheel scrolling (does nothing on phones / tablets / trackpads)
initSmoothWheel()
