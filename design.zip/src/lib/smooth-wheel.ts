/**
 * PC only: eased ("inertia") mouse-wheel scrolling.
 *
 * A normal mouse wheel jumps ~100px per notch. Here every notch only moves a target position and the
 * page glides to it (exponential easing, frame-rate independent), so scrolling down the page feels
 * soft and continuous at any refresh rate (60 / 120 / 144 Hz).
 *
 * It stays out of the way: phones / touch screens / trackpads / keyboard / scroll-bar dragging /
 * modals / inner scroll areas / pinch-zoom all keep the browser's own scrolling.
 */
export function initSmoothWheel(): () => void {
  const noop = () => {};
  if (typeof window === "undefined") return noop;

  // Only a real mouse on a desktop-size screen. Phones and tablets are never touched.
  const desktop = window.matchMedia("(min-width: 1024px) and (hover: hover) and (pointer: fine)");
  const reduced = window.matchMedia("(prefers-reduced-motion: reduce)");
  if (!desktop.matches || reduced.matches) return noop;

  const root = document.documentElement;
  const TAU = 95; // ms - bigger = floatier. ~95ms feels smooth without feeling late.
  const STEP = 1.0; // wheel distance multiplier

  let target = window.scrollY;
  let current = window.scrollY;
  let lastSet = window.scrollY;
  let raf = 0;
  let last = 0;

  const maxScroll = () => Math.max(0, root.scrollHeight - window.innerHeight);
  const clamp = (v: number) => Math.min(maxScroll(), Math.max(0, v));

  // Is there an inner scroll area under the pointer that can still move in this direction?
  const innerCanScroll = (start: EventTarget | null, dy: number) => {
    let el = start instanceof Element ? start : null;
    while (el && el !== document.body && el !== root) {
      const oy = getComputedStyle(el).overflowY;
      if ((oy === "auto" || oy === "scroll") && el.scrollHeight > el.clientHeight + 1) {
        if (dy < 0 ? el.scrollTop > 0 : el.scrollTop + el.clientHeight < el.scrollHeight - 1) return true;
      }
      el = el.parentElement;
    }
    return false;
  };

  const tick = (t: number) => {
    const dt = Math.min(64, t - last);
    last = t;
    const diff = target - current;
    if (Math.abs(diff) < 0.4) {
      current = target;
      window.scrollTo(0, current);
      lastSet = window.scrollY;
      raf = 0;
      return;
    }
    current += diff * (1 - Math.exp(-dt / TAU));
    window.scrollTo(0, current);
    lastSet = window.scrollY;
    raf = requestAnimationFrame(tick);
  };

  const onWheel = (e: WheelEvent) => {
    if (e.defaultPrevented || e.ctrlKey || e.metaKey || e.shiftKey) return; // zoom / horizontal
    if (Math.abs(e.deltaX) > Math.abs(e.deltaY)) return;
    if (root.classList.contains("modal-open") || root.classList.contains("menu-open")) return;
    if (document.querySelector(".modal-overlay.active")) return;
    if (innerCanScroll(e.target, e.deltaY)) return;

    let dy = e.deltaY;
    if (e.deltaMode === 1) dy *= 40;
    else if (e.deltaMode === 2) dy *= window.innerHeight;

    // Trackpads send many tiny deltas and already glide natively: leave them alone
    // (unless a wheel glide is already running, then keep it consistent).
    if (!raf && e.deltaMode === 0 && Math.abs(e.deltaY) < 50) return;

    e.preventDefault();

    // Page was moved by something else (scroll bar, keyboard, menu jump): continue from there
    if (!raf || Math.abs(window.scrollY - lastSet) > 2) {
      current = target = window.scrollY;
    }
    target = clamp(target + dy * STEP);
    if (!raf) {
      last = performance.now();
      raf = requestAnimationFrame(tick);
    }
  };

  window.addEventListener("wheel", onWheel, { passive: false });
  return () => {
    window.removeEventListener("wheel", onWheel);
    if (raf) cancelAnimationFrame(raf);
  };
}
