/**
 * Cute synthesized "meow" (Web Audio API) - no audio file needed.
 * Two sound layers: a pitch-gliding voice through moving vowel filters
 * ("mee" -> "ow"), plus a soft breathy noise. Each call is slightly different.
 */
let ctx: AudioContext | null = null;

function getCtx(): AudioContext | null {
  try {
    const AC = window.AudioContext || (window as any).webkitAudioContext;
    if (!AC) return null;
    if (!ctx) ctx = new AC();
    if (ctx.state === "suspended") void ctx.resume();
    return ctx;
  } catch {
    return null;
  }
}

/** Try to start the audio engine. Returns true when sound is allowed (a user gesture happened). */
export function unlockAudio(): boolean {
  const ac = getCtx();
  return !!ac && ac.state === "running";
}

export interface MeowOptions {
  /** seconds from now */
  delay?: number;
  /** pitch multiplier (1 = normal) */
  pitch?: number;
  /** length multiplier (1 = normal) */
  length?: number;
  /** volume multiplier (1 = normal) */
  volume?: number;
}

/** Plays one meow and returns its length in seconds. */
export function playMeow(opts: MeowOptions = {}): number {
  const ac = getCtx();
  if (!ac) return 0;

  const t0 = ac.currentTime + 0.01 + (opts.delay ?? 0);
  const dur = (0.55 + Math.random() * 0.08) * (opts.length ?? 1);
  const pitch = (opts.pitch ?? 1) * (1 + (Math.random() - 0.5) * 0.14); // small random variation
  const vol = opts.volume ?? 1;

  const master = ac.createGain();
  master.gain.setValueAtTime(0.0001, t0);
  master.gain.exponentialRampToValueAtTime(0.5 * vol, t0 + 0.06);
  master.gain.setValueAtTime(0.5 * vol, t0 + dur * 0.55);
  master.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  master.connect(ac.destination);

  // Voice: slide up ("mee") then down ("ow")
  const osc = ac.createOscillator();
  osc.type = "sawtooth";
  osc.frequency.setValueAtTime(520 * pitch, t0);
  osc.frequency.exponentialRampToValueAtTime(980 * pitch, t0 + dur * 0.35);
  osc.frequency.exponentialRampToValueAtTime(560 * pitch, t0 + dur);

  // gentle vibrato
  const lfo = ac.createOscillator();
  const lfoGain = ac.createGain();
  lfo.frequency.value = 22;
  lfoGain.gain.value = 14;
  lfo.connect(lfoGain).connect(osc.frequency);

  // Vowel formants: "ee" (high 2nd formant) -> "ow" (low)
  const f1 = ac.createBiquadFilter();
  f1.type = "bandpass";
  f1.Q.value = 5;
  f1.frequency.setValueAtTime(450, t0);
  f1.frequency.linearRampToValueAtTime(900, t0 + dur * 0.7);
  const f2 = ac.createBiquadFilter();
  f2.type = "bandpass";
  f2.Q.value = 7;
  f2.frequency.setValueAtTime(2600, t0);
  f2.frequency.linearRampToValueAtTime(1300, t0 + dur * 0.8);

  const g1 = ac.createGain();
  g1.gain.value = 1.2;
  const g2 = ac.createGain();
  g2.gain.value = 0.9;
  osc.connect(f1).connect(g1).connect(master);
  osc.connect(f2).connect(g2).connect(master);

  // Soft breath at the start
  const len = Math.floor(ac.sampleRate * 0.15);
  const buf = ac.createBuffer(1, len, ac.sampleRate);
  const data = buf.getChannelData(0);
  for (let i = 0; i < len; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / len);
  const noise = ac.createBufferSource();
  noise.buffer = buf;
  const nf = ac.createBiquadFilter();
  nf.type = "highpass";
  nf.frequency.value = 3000;
  const ng = ac.createGain();
  ng.gain.value = 0.06;
  noise.connect(nf).connect(ng).connect(master);

  osc.start(t0);
  lfo.start(t0);
  noise.start(t0);
  osc.stop(t0 + dur + 0.05);
  lfo.stop(t0 + dur + 0.05);
  return dur;
}

/**
 * Big intro meow: a long happy "mee-yaaow" followed by a soft little "mew".
 * Returns the total length in milliseconds.
 */
export function playMeowIntro(): number {
  const a = playMeow({ pitch: 1.05, length: 1.55, volume: 1.15 });
  const gap = a + 0.12;
  const b = playMeow({ delay: gap, pitch: 1.3, length: 0.95, volume: 0.8 });
  return Math.round((gap + b) * 1000);
}
