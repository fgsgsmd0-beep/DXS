import { useEffect, useRef } from "react";

/**
 * Phone / tablet scroll bar (< 1024px).
 * Phone browsers hide their own scroll bar, so this draws a slim lightning-style rail on the right
 * edge in the site colours (white + soft blue on black). It shows while scrolling, fades out when
 * idle, and the thumb can be dragged to move up and down the page quickly.
 * (On PC the real browser scroll bar is styled with CSS instead - see index.css.)
 */
export default function MobileScrollBar() {
  const railRef = useRef<HTMLDivElement>(null);
  const thumbRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const rail = railRef.current;
    const thumb = thumbRef.current;
    if (!rail || !thumb) return;
    const root = document.documentElement;

    let raf = 0;
    let hideTimer = 0;
    let dragging = false;
    let startY = 0;
    let startScroll = 0;

    const metrics = () => {
      const view = window.innerHeight;
      const doc = root.scrollHeight;
      const max = Math.max(1, doc - view);
      const trackH = rail.clientHeight;
      const thumbH = Math.max(40, Math.min(trackH, (trackH * view) / Math.max(doc, 1)));
      return { max, trackH, thumbH, scrollable: doc - view > 8 };
    };

    // The page size is measured only when it can change (resize / content growth), then cached.
    // Reading scrollHeight / clientHeight on every scroll event forces the browser to re-check
    // layout in the middle of a scroll, which is what makes a phone stutter.
    let cache = metrics();
    let lastThumbH = -1;
    const refresh = () => { cache = metrics(); };

    const update = () => {
      raf = 0;
      const { max, trackH, thumbH } = cache;
      const p = Math.min(1, Math.max(0, window.scrollY / max));
      if (thumbH !== lastThumbH) {
        thumb.style.height = thumbH + "px";
        lastThumbH = thumbH;
      }
      thumb.style.transform = `translate3d(0, ${(trackH - thumbH) * p}px, 0)`;
    };

    const show = () => {
      if (!cache.scrollable) return;
      rail.classList.add("is-on");
      window.clearTimeout(hideTimer);
      if (!dragging) hideTimer = window.setTimeout(() => rail.classList.remove("is-on"), 1200);
    };

    const onScroll = () => {
      if (!raf) raf = requestAnimationFrame(update);
      show();
    };

    const onDown = (e: PointerEvent) => {
      dragging = true;
      startY = e.clientY;
      startScroll = window.scrollY;
      thumb.setPointerCapture(e.pointerId);
      rail.classList.add("is-drag", "is-on");
      window.clearTimeout(hideTimer);
      e.preventDefault();
    };
    const onMove = (e: PointerEvent) => {
      if (!dragging) return;
      const { max, trackH, thumbH } = cache;
      const ratio = max / Math.max(1, trackH - thumbH);
      window.scrollTo({ top: startScroll + (e.clientY - startY) * ratio, behavior: "instant" as ScrollBehavior });
    };
    const onUp = () => {
      if (!dragging) return;
      dragging = false;
      rail.classList.remove("is-drag");
      show();
    };

    const onResize = () => {
      refresh();
      onScroll();
    };

    update();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onResize, { passive: true });

    // Page height changes when the cards chunk loads / images settle: re-measure then (not per scroll)
    let ro: ResizeObserver | null = null;
    if (typeof ResizeObserver !== "undefined") {
      ro = new ResizeObserver(() => {
        refresh();
        if (!raf) raf = requestAnimationFrame(update);
      });
      ro.observe(document.body);
    }
    thumb.addEventListener("pointerdown", onDown);
    thumb.addEventListener("pointermove", onMove);
    thumb.addEventListener("pointerup", onUp);
    thumb.addEventListener("pointercancel", onUp);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onResize);
      ro?.disconnect();
      thumb.removeEventListener("pointerdown", onDown);
      thumb.removeEventListener("pointermove", onMove);
      thumb.removeEventListener("pointerup", onUp);
      thumb.removeEventListener("pointercancel", onUp);
      window.clearTimeout(hideTimer);
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);

  return (
    <div ref={railRef} className="m-scroll" aria-hidden="true">
      <div ref={thumbRef} className="m-scroll-thumb" />
    </div>
  );
}
