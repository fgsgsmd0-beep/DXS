import React, { useEffect, useRef, useState } from "react";
import { m } from "motion/react";
import {
  Home,
  Globe,
  Smartphone,
  Bot,
  Key,
  Star,
  Monitor,
  ArrowRight,
  ArrowUpRight,
  Send,
} from "lucide-react";
import { PcSocialDock } from "./pc-social-dock";

/**
 * PC-only hero ("Hero Odyssey" design) for the Home page.
 * Phones keep their own hero layout, but share this page background (see PcBackground).
 * It must be rendered inside <LazyMotion> (see hero.tsx).
 */

/* ------------------------------------------------------------------ */
/* WebGL lightning                                                     */
/* ------------------------------------------------------------------ */

interface LightningProps {
  hue?: number;
  xOffset?: number;
  speed?: number;
  intensity?: number;
  size?: number;
  /** Render resolution factor (1 = full). Phones use less so the shader stays smooth. */
  scale?: number;
  /** How far the beam may wander sideways (1 = PC). Phones are narrow, so a smaller value keeps the beam near the centre like on PC. */
  warp?: number;
  /** fbm detail levels (10 = PC). Phones use fewer to stay smooth. */
  octaves?: number;
  /** Frame-rate cap (0 = none). Phones render the background at 30fps to save battery/heat. */
  maxFps?: number;
  /** Phones: freeze the background while the finger is scrolling, so scrolling never competes with the GPU. */
  pauseOnScroll?: boolean;
  /** Phones: keep drawing while scrolling, but at this lower frame-rate (instead of freezing). */
  scrollFps?: number;
}

const Lightning: React.FC<LightningProps> = ({
  hue = 230,
  xOffset = 0,
  speed = 1,
  intensity = 1,
  size = 1,
  scale = 1,
  warp = 1,
  octaves = 10,
  maxFps = 0,
  pauseOnScroll = false,
  scrollFps = 0,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Phone mode (the only one that passes pauseOnScroll). PC keeps its exact original behaviour.
    const mobile = maxFps > 0;

    const gl = canvas.getContext(
      "webgl",
      mobile
        ? { antialias: false, alpha: false, depth: false, stencil: false, powerPreference: "low-power" }
        : { antialias: false, powerPreference: "low-power" }
    );
    if (!gl) return;

    // Phone: the size is measured by a ResizeObserver (cached), never read from the DOM every frame
    // (that forces a layout in the middle of a scroll).
    // Emulator / software GPU: start the shader at a smaller render size (the beam is a soft glow, so
    // the picture looks the same) instead of waiting for the auto-quality to step down slowly.
    const softGpu = document.documentElement.classList.contains("soft-gpu");
    let curScale = softGpu && !mobile ? Math.min(scale, 0.55) : scale; // phones: may step down if the GPU cannot keep up (see render)
    let cssW = canvas.clientWidth;
    let cssH = canvas.clientHeight;

    const resizeCanvas = () => {
      if (!mobile) {
        // PC: size comes from the cached ResizeObserver values (no layout read every frame).
        // Only touch the canvas when it really changed (assigning clears the buffer).
        const w = Math.max(1, Math.round(cssW * curScale));
        const h = Math.max(1, Math.round(cssH * curScale));
        if (canvas.width === w && canvas.height === h) return false;
        canvas.width = w;
        canvas.height = h;
        return true;
      }
      const w = Math.max(1, Math.round(cssW * curScale));
      const h = Math.max(1, Math.round(cssH * curScale));
      if (canvas.width === w && canvas.height === h) return false;
      // The browser address bar sliding in/out nudges the height while scrolling. The canvas is
      // CSS-stretched, so a small height change is invisible - skip re-allocating the buffer.
      if (canvas.width === w && canvas.height > 1 && Math.abs(h - canvas.height) < canvas.height * 0.2) return false;
      canvas.width = w;
      canvas.height = h;
      return true;
    };
    resizeCanvas();

    const vertexShaderSource = `
      attribute vec2 aPosition;
      void main() {
        gl_Position = vec4(aPosition, 0.0, 1.0);
      }
    `;

    const fragmentShaderSource = `
      #ifdef GL_FRAGMENT_PRECISION_HIGH
      precision highp float;
      #else
      precision mediump float;
      #endif
      uniform vec2 iResolution;
      uniform float iTime;
      uniform float uHue;
      uniform float uXOffset;
      uniform float uSpeed;
      uniform float uIntensity;
      uniform float uSize;
      uniform float uWarp;

      #define OCTAVE_COUNT ${octaves}
      #define SMOOTH_FLICKER ${mobile ? 1 : 0}

      vec3 hsv2rgb(vec3 c) {
          vec3 rgb = clamp(abs(mod(c.x * 6.0 + vec3(0.0,4.0,2.0), 6.0) - 3.0) - 1.0, 0.0, 1.0);
          return c.z * mix(vec3(1.0), rgb, c.y);
      }

      float hash11(float p) {
          p = fract(p * .1031);
          p *= p + 33.33;
          p *= p + p;
          return fract(p);
      }

      float hash12(vec2 p) {
          vec3 p3 = fract(vec3(p.xyx) * .1031);
          p3 += dot(p3, p3.yzx + 33.33);
          return fract((p3.x + p3.y) * p3.z);
      }

      // Phones: the beam brightness pulses smoothly instead of jumping to a new random value every
      // frame (that per-frame strobe is what looked "laggy"). Same average brightness, same pulsing feel.
      float flick(float t) {
          float i = floor(t);
          float f = fract(t);
          f = f * f * (3.0 - 2.0 * f);
          return clamp((mix(hash11(i), hash11(i + 1.0), f) - 0.5) * 1.5 + 0.5, 0.0, 1.0);
      }

      mat2 rotate2d(float theta) {
          float c = cos(theta);
          float s = sin(theta);
          return mat2(c, -s, s, c);
      }

      float noise(vec2 p) {
          vec2 ip = floor(p);
          vec2 fp = fract(p);
          float a = hash12(ip);
          float b = hash12(ip + vec2(1.0, 0.0));
          float c = hash12(ip + vec2(0.0, 1.0));
          float d = hash12(ip + vec2(1.0, 1.0));

          vec2 t = smoothstep(0.0, 1.0, fp);
          return mix(mix(a, b, t.x), mix(c, d, t.x), t.y);
      }

      float fbm(vec2 p) {
          float value = 0.0;
          float amplitude = 0.5;
          for (int i = 0; i < OCTAVE_COUNT; ++i) {
              value += amplitude * noise(p);
              p *= rotate2d(0.45);
              p *= 2.0;
              amplitude *= 0.5;
          }
          return value;
      }

      #if SMOOTH_FLICKER == 1
      #define FLICK flick(iTime * uSpeed * 6.0)
      #else
      #define FLICK hash11(iTime * uSpeed)
      #endif

      void mainImage( out vec4 fragColor, in vec2 fragCoord ) {
          vec2 uv = fragCoord / iResolution.xy;
          uv = 2.0 * uv - 1.0;
          uv.x *= iResolution.x / iResolution.y;
          uv.x += uXOffset;

          uv += uWarp * (2.0 * fbm(uv * uSize + 0.8 * iTime * uSpeed) - 1.0);

          float dist = abs(uv.x);
          vec3 baseColor = hsv2rgb(vec3(uHue / 360.0, 0.7, 0.8));
          vec3 col = baseColor * pow(mix(0.0, 0.07, FLICK) / dist, 1.0) * uIntensity;
          col = pow(col, vec3(1.0));
          fragColor = vec4(col, 1.0);
      }

      void main() {
          mainImage(gl_FragColor, gl_FragCoord.xy);
      }
    `;

    const compileShader = (source: string, type: number): WebGLShader | null => {
      const shader = gl.createShader(type);
      if (!shader) return null;
      gl.shaderSource(shader, source);
      gl.compileShader(shader);
      if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
        console.error("Shader compile error:", gl.getShaderInfoLog(shader));
        gl.deleteShader(shader);
        return null;
      }
      return shader;
    };

    const vertexShader = compileShader(vertexShaderSource, gl.VERTEX_SHADER);
    const fragmentShader = compileShader(fragmentShaderSource, gl.FRAGMENT_SHADER);
    if (!vertexShader || !fragmentShader) return;

    const program = gl.createProgram();
    if (!program) return;
    gl.attachShader(program, vertexShader);
    gl.attachShader(program, fragmentShader);
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
      console.error("Program linking error:", gl.getProgramInfoLog(program));
      return;
    }
    gl.useProgram(program);

    const vertices = new Float32Array([-1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, 1]);
    const vertexBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW);

    const aPosition = gl.getAttribLocation(program, "aPosition");
    gl.enableVertexAttribArray(aPosition);
    gl.vertexAttribPointer(aPosition, 2, gl.FLOAT, false, 0, 0);

    const iResolutionLocation = gl.getUniformLocation(program, "iResolution");
    const iTimeLocation = gl.getUniformLocation(program, "iTime");
    const uHueLocation = gl.getUniformLocation(program, "uHue");
    const uXOffsetLocation = gl.getUniformLocation(program, "uXOffset");
    const uSpeedLocation = gl.getUniformLocation(program, "uSpeed");
    const uIntensityLocation = gl.getUniformLocation(program, "uIntensity");
    const uSizeLocation = gl.getUniformLocation(program, "uSize");
    const uWarpLocation = gl.getUniformLocation(program, "uWarp");

    // These never change, so they are uploaded once instead of every frame
    gl.uniform1f(uHueLocation, hue);
    gl.uniform1f(uXOffsetLocation, xOffset);
    gl.uniform1f(uSpeedLocation, speed);
    gl.uniform1f(uIntensityLocation, intensity);
    gl.uniform1f(uSizeLocation, size);
    gl.uniform1f(uWarpLocation, warp);

    let raf = 0;
    let visible = true;
    let lastDraw = 0;
    let lastScroll = 0;
    let minFrame = maxFps > 0 ? 1000 / maxFps - 2 : 0;
    // Phone auto-quality: measure real frame times; if the phone cannot hold ~45fps, lower the render
    // size a step (at most 2 steps), then fall back to a steady 30fps. Never changes on a fast phone.
    let lastTick = 0;
    let dtSum = 0;
    let dtN = 0;
    let steps = 0;
    let pcSteps = 0;
    let goodWindows = 0;
    const startTime = performance.now();
    const rootClasses = document.documentElement.classList;

    const onScroll = () => { lastScroll = performance.now(); };
    if (pauseOnScroll || scrollFps) window.addEventListener("scroll", onScroll, { passive: true });

    const draw = (now: number) => {
      resizeCanvas();
      gl.viewport(0, 0, canvas.width, canvas.height);
      gl.uniform2f(iResolutionLocation, canvas.width, canvas.height);
      gl.uniform1f(iTimeLocation, (now - startTime) / 1000.0);
      gl.drawArrays(gl.TRIANGLES, 0, 6);
    };

    const render = () => {
      raf = requestAnimationFrame(render);
      if (mobile && steps < 5) {
        const t = performance.now();
        const dt = t - lastTick;
        lastTick = t;
        // only count smooth stretches (ignore pauses: hidden tab, modal, scroll jank spikes)
        if (dt < 100 && visible && !document.hidden) { dtSum += dt; dtN++; }
        if (dtN >= 60) {
          const avg = dtSum / dtN;
          dtSum = 0; dtN = 0;
          if (avg > 22) {
            steps++;
            if (steps <= 4) {
              curScale = Math.max(0.22, curScale * 0.8);
              if (resizeCanvas()) draw(t);
            } else {
              minFrame = 1000 / 30 - 2;
            }
          } else if (steps === 0 && avg < 18) {
            steps = 5; // holds full speed comfortably: stop measuring
          }
        }
      }
      // PC auto-quality (dynamic resolution): only if the PC cannot hold ~50fps while idle, the shader
      // is rendered a little smaller (the glow is soft, so it is not visible). Fast PCs never change.
      if (!mobile && pcSteps < 6) {
        const t = performance.now();
        const dt = t - lastTick;
        lastTick = t;
        const busy = t - lastScroll < 250;
        if (dt < 100 && visible && !document.hidden && !busy) { dtSum += dt; dtN++; }
        if (dtN >= 90) {
          const avg = dtSum / dtN;
          dtSum = 0; dtN = 0;
          if (avg > 20) {
            goodWindows = 0;
            pcSteps++;
            curScale = Math.max(softGpu ? 0.35 : 0.5, curScale * 0.85);
            draw(t);
          } else if (++goodWindows >= 3) {
            pcSteps = 6; // holds full speed comfortably: stop measuring
          }
        }
      }
      // Skip the GPU work when: hero is off-screen, a modal / the phone menu is open, the tab is hidden,
      // the finger is scrolling (phones) or the frame-rate cap says "not yet"
      // PC: the lightning keeps running behind popups (modal-open); phones still rest while a popup / menu is open
      if (!visible || document.hidden || (mobile && (rootClasses.contains('modal-open') || rootClasses.contains('menu-open')))) return;
      const now = performance.now();
      const scrolling = now - lastScroll < 140;
      if (pauseOnScroll && scrolling) return;
      const frame = scrolling && scrollFps ? 1000 / scrollFps - 2 : minFrame;
      if (frame && now - lastDraw < frame) return;
      lastDraw = now;
      draw(now);
    };
    raf = requestAnimationFrame(render);

    // When the size really changes, redraw right away so the cleared buffer never flashes
    let ro: ResizeObserver | null = null;
    if (typeof ResizeObserver !== "undefined") {
      ro = new ResizeObserver((entries) => {
        const r = entries[0].contentRect;
        cssW = r.width;
        cssH = r.height;
        if (resizeCanvas()) draw(performance.now());
      });
      ro.observe(canvas);
    }

    const io = new IntersectionObserver(([entry]) => {
      visible = entry.isIntersecting;
    });
    io.observe(canvas);

    return () => {
      cancelAnimationFrame(raf);
      if (pauseOnScroll || scrollFps) window.removeEventListener("scroll", onScroll);
      io.disconnect();
      ro?.disconnect();
      gl.deleteProgram(program);
      gl.deleteShader(vertexShader);
      gl.deleteShader(fragmentShader);
      gl.deleteBuffer(vertexBuffer);
    };
  }, [hue, xOffset, speed, intensity, size, scale, warp, octaves, maxFps, pauseOnScroll, scrollFps]);

  return <canvas ref={canvasRef} className="w-full h-full relative block" />;
};

/* ------------------------------------------------------------------ */
/* Floating feature labels (click = jump to that section)              */
/* ------------------------------------------------------------------ */

/* ------------------------------------------------------------------ */
/* Hero                                                                */
/* ------------------------------------------------------------------ */

const NAV_ITEMS = [
  { name: "Home", icon: Home },
  { name: "Free Web", icon: Globe },
  { name: "APK", icon: Smartphone },
  { name: "BOT", icon: Bot },
  { name: "API", icon: Key },
  { name: "Review", icon: Star },
  { name: "PC Tools", icon: Monitor },
];

const VerifiedBadge = () => (
  <span title="Verified Creator" className="inline-flex items-center">
    <svg viewBox="0 0 24 24" className="w-[15px] h-[15px] fill-[#00F2FE] flex-shrink-0 drop-shadow-[0_0_8px_rgba(0,242,254,0.8)]" aria-hidden="true">
      <path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10 10-4.5 10-10S17.5 2 12 2zm-1.2 14.2l-3.5-3.5 1.4-1.4 2.1 2.1 5.3-5.3 1.4 1.4-6.7 6.7z" />
    </svg>
  </span>
);

/* ------------------------------------------------------------------ */
/* PC top bar: fixed to the top of the screen (like the phone site),   */
/* so it stays visible the whole time while scrolling.                 */
/* Left: profile  |  Right: page shortcuts                               */
/* video player                                                        */
/* ------------------------------------------------------------------ */

const PcTopBar: React.FC<{ activeTab: string; onNavigate: (name: string) => void }> = ({
  activeTab,
  onNavigate,
}) => {
  const [scrolled, setScrolled] = useState(false);
  const [atTop, setAtTop] = useState(true);

  useEffect(() => {
    let raf = 0;
    const update = () => {
      raf = 0;
      const y = window.scrollY;
      setScrolled(y > 12);
      setAtTop(y < 140);
    };
    const onScroll = () => {
      if (!raf) raf = requestAnimationFrame(update);
    };
    update();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      window.removeEventListener("scroll", onScroll);
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);

  // At the very top the highlight is always "Home" (even after the visitor scrolled up by hand)
  const shown = atTop ? "Home" : activeTab === "Home" ? "" : activeTab;

  const chip =
    "group h-10 pl-1.5 pr-1.5 xl:pr-4 rounded-full border border-white/10 bg-white/[0.05] hover:bg-white/[0.10] text-[13px] font-semibold text-white/85 hover:text-white no-underline flex items-center gap-2 transition-all duration-300 hover:-translate-y-0.5";

  return (
    <m.header
      initial={{ y: -28, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5, ease: "easeOut" }}
      className={`pc-topbar fixed top-0 inset-x-0 z-[300] ${scrolled ? "is-scrolled" : ""}`}
    >
      <div className="relative w-full h-[54px] pl-3 pr-4 xl:pl-4 xl:pr-6 grid grid-cols-[1fr_auto] items-center gap-4">
        {/* ---- Left: profile ---- */}
        <button
          type="button"
          onClick={() => onNavigate("Home")}
          aria-label="Go to top"
          className="justify-self-start flex items-center gap-3 bg-transparent border-0 p-0 cursor-pointer text-left select-none group"
        >
          <span className="relative flex-shrink-0 w-[36px] h-[36px] rounded-full p-px bg-[rgba(157,184,255,0.30)] shadow-[0_4px_12px_rgba(0,0,0,0.35)] transition-transform duration-300 group-hover:scale-105">
            <img
              src="/avatar-120.jpg"
              srcSet="/avatar-80.jpg 80w, /avatar-120.jpg 120w, /avatar-160.jpg 160w"
              sizes="36px"
              alt="Dev Yasin"
              width={36}
              height={36}
              decoding="async"
              className="block w-full h-full rounded-full object-cover"
            />
          </span>
          <span className="flex flex-col leading-tight">
            <span className="flex items-center gap-1.5">
              <span className="pc-brand-text font-black text-[0.9rem] text-white tracking-tight whitespace-nowrap">Dev Yasin</span>
              <VerifiedBadge />
            </span>
            <span className="pc-brand-text font-bold text-[0.46rem] tracking-[2.2px] uppercase text-[#9DB8FF] whitespace-nowrap mt-0.5">
              Official Website
            </span>
          </span>
        </button>

        {/* ---- Right: page shortcuts (Home, Free Web, APK, BOT, API, Review, PC Tools) ---- */}
        <nav aria-label="Main" className="pc-navpill justify-self-end flex items-center">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = shown === item.name;
            return (
              <button
                key={item.name}
                type="button"
                onClick={() => onNavigate(item.name)}
                className={`pc-navbtn ${isActive ? "is-active" : ""}`}
              >
                <Icon size={12} strokeWidth={2} className="pc-navicon hidden xl:block" />
                <span>{item.name}</span>
              </button>
            );
          })}
        </nav>

      </div>
    </m.header>
  );
};

/* ------------------------------------------------------------------ */
/* PC page background: fixed to the screen, so the lightning, glow and  */
/* planet stay behind EVERYTHING while scrolling (no cut line / seam).  */
/* Rendered once from demo.tsx on wide screens only.                    */
/* ------------------------------------------------------------------ */

/* ------------------------------------------------------------------ */
/* Phone / tablet background: a few small light particles that fall    */
/* from the top in a gentle curve, each at its own speed. Only 5        */
/* elements, transform + opacity only (GPU compositor): no lag, even    */
/* while scrolling.                                                     */
/* ------------------------------------------------------------------ */

const FALLERS = [
  { left: "11%", size: 4, dur: 11, delay: -3, sway: 26, swayDur: 4.2, color: "#9DB8FF" },
  { left: "30%", size: 3, dur: 16, delay: -9, sway: 18, swayDur: 5.6, color: "#ffffff" },
  { left: "52%", size: 5, dur: 13, delay: -6, sway: 30, swayDur: 4.8, color: "#6F9BFF" },
  { left: "72%", size: 3, dur: 19, delay: -13, sway: 22, swayDur: 6.2, color: "#C4D5FF" },
  { left: "89%", size: 4, dur: 9, delay: -1.5, sway: 20, swayDur: 3.8, color: "#9DB8FF" },
];

const MobileParticles: React.FC = React.memo(() => (
  <div className="absolute inset-0 overflow-hidden">
    <div className="mp-halo" />
    {FALLERS.map((f, i) => (
      <span
        key={i}
        className="mp-fall"
        style={{ left: f.left, animationDuration: `${f.dur}s`, animationDelay: `${f.delay}s` }}
      >
        <span
          className="mp-sway"
          style={
            {
              animationDuration: `${f.swayDur}s`,
              ["--sw" as string]: `${f.sway}px`,
              ["--pc" as string]: f.color,
              width: f.size,
              height: f.size,
            } as React.CSSProperties
          }
        />
      </span>
    ))}
  </div>
));

export const PcBackground: React.FC<{
  hue?: number;
  xOffset?: number;
  speed?: number;
  intensity?: number;
  size?: number;
  /** Phone / tablet: same look, rendered at a lower resolution */
  compact?: boolean;
}> = ({ hue = 220, xOffset = -0.55, speed = 1.6, intensity = 1.1, size = 2, compact = false }) => {
  // PC: WebGL lightning. Phone / tablet: lightweight particle field (CSS compositor animations only).
  return (
  <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden bg-black" aria-hidden="true">
    <div className="absolute inset-0 bg-black/80" />

    {/* Central light beam */}
    {!compact && <div className="absolute inset-0">
      <Lightning hue={hue} xOffset={xOffset} speed={speed} intensity={compact ? intensity * 0.72 : intensity} size={size} scale={compact ? (document.documentElement.classList.contains("lite") ? 0.34 : 0.42) : 1} warp={compact ? 0.2 : 1} octaves={compact ? 5 : 10} maxFps={compact ? 60 : 0} />
    </div>}
    {compact && <MobileParticles />}
  </div>
);
};

interface HeroOdysseyProps {
  activeTab: string;
  onNavigate: (name: string) => void;
}

const SERVICES = [
  { n: "01", name: "Free Website", sub: "build & host", desc: "Fast, modern websites, hosted for free.", nav: "Free Web", icon: Globe },
  { n: "02", name: "APK Building", sub: "apps for Android", desc: "Android apps built and ready to install.", nav: "APK", icon: Smartphone },
  { n: "03", name: "Bot Making", sub: "smart automation", desc: "Bots that work on their own, day and night.", nav: "BOT", icon: Bot },
  { n: "04", name: "API Key", sub: "instant access", desc: "Get your key instantly, no waiting around.", nav: "API", icon: Key },
];

export const HeroOdyssey: React.FC<HeroOdysseyProps> = ({ activeTab, onNavigate }) => {
  const container = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.14, delayChildren: 0.2 } },
  };
  const item = {
    hidden: { y: 22, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { duration: 0.9, ease: [0.16, 1, 0.3, 1] as const } },
  };
  const titleIn = {
    hidden: { y: 40, opacity: 0, filter: "blur(16px)" },
    visible: { y: 0, opacity: 1, filter: "blur(0px)", transition: { duration: 1.3, ease: [0.16, 1, 0.3, 1] as const } },
  };

  return (
    <div className="relative w-full text-white">
      <PcTopBar activeTab={activeTab} onNavigate={onNavigate} />

      {/* PC: small cat in the bottom-right corner (YouTube, TikTok, video) */}
      <PcSocialDock />

      <div className="pc-hero relative z-20 w-full px-[5.2vw] h-screen min-h-[760px] flex flex-col pt-[54px]">
        {/* ---------- headline ---------- */}
        <m.div
          variants={container}
          initial="hidden"
          animate="visible"
          className="flex-1 flex flex-col justify-center max-w-[900px]"
        >
          <m.p variants={item} className="pc-kicker mb-9">
            <span className="pc-kicker-dot" />
            Welcome Developer Website
          </m.p>

          <m.div variants={titleIn}>
            <h1 className="pc-hero-title text-[6.6rem] xl:text-[9rem] 2xl:text-[10.6rem] leading-[0.88] font-light tracking-[-0.055em] -ml-[0.4rem]">
              Dev Yasin
            </h1>
          </m.div>

          <m.h2
            variants={item}
            className="mt-7 text-[2.3rem] xl:text-[3rem] leading-[1.1] text-[#C4D5FF]/80"
            style={{ fontFamily: "'Instrument Serif', Georgia, serif", fontStyle: "italic", fontWeight: 400 }}
          >
            Creative Developer <span className="text-white/30">·</span> Video Creator
          </m.h2>

          <m.p variants={item} className="mt-6 text-[1.02rem] leading-relaxed text-[#C4D5FF]/55 max-w-[460px]">
            Free websites, APK building, bots and API keys — all in one place.
          </m.p>

          <m.div variants={item} className="mt-11 flex items-center gap-8">
            <a
              href="https://t.me/auraffxofficial"
              target="_blank"
              rel="noopener noreferrer"
              className="pc-cta-white group inline-flex items-center gap-3 h-[54px] pl-7 pr-2 rounded-full no-underline font-semibold text-[0.93rem] whitespace-nowrap"
            >
              <Send size={16} className="-rotate-12" />
              Join Telegram Channel
              <span className="pc-cta-white-arrow w-10 h-10 rounded-full flex items-center justify-center transition-transform duration-300 group-hover:rotate-45">
                <ArrowUpRight size={17} strokeWidth={2.4} />
              </span>
            </a>
            <button
              type="button"
              onClick={() => onNavigate("PC Tools")}
              className="pc-link inline-flex items-center gap-2 text-[0.93rem] font-medium text-white/80 hover:text-white cursor-pointer bg-transparent border-0 p-0 whitespace-nowrap"
            >
              <span className="pc-link-text">Free PC tools</span>
              <ArrowRight size={15} />
            </button>
          </m.div>
        </m.div>

        {/* ---------- services: clean editorial row ---------- */}
        <m.div variants={container} initial="hidden" animate="visible" className="grid grid-cols-4 gap-x-10 pb-10">
          {SERVICES.map((sv) => (
            <m.button
              key={sv.n}
              variants={item}
              type="button"
              onClick={() => onNavigate(sv.nav)}
              className="pc-row group relative text-left cursor-pointer bg-transparent border-0 pt-6 pb-2"
            >
              <span aria-hidden="true" className="pc-row-line" />
              <div className="flex items-center gap-5">
                <span className="pc-row-n inline-block w-8" style={{ fontFamily: "'Orbitron', sans-serif" }}>{sv.n}</span>
                <span className="flex-1 min-w-0">
                  <span className="pc-row-name block text-[1.4rem] xl:text-[1.55rem] font-medium tracking-tight leading-tight">{sv.name}</span>
                  <span className="pc-row-sub block mt-1 text-[0.85rem]">{sv.sub}</span>
                </span>
                <ArrowUpRight size={20} className="pc-row-arrow flex-shrink-0" />
              </div>
            </m.button>
          ))}
        </m.div>
      </div>
    </div>
  );
};

export default HeroOdyssey;
