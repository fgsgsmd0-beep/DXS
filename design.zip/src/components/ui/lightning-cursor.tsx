import React from 'react';

/**
 * PC-only lightning cursor.
 *
 * - The normal arrow is replaced by a glowing lightning bolt.
 * - Moving the mouse leaves a crackling electric trail that forks into small branches.
 * - Over buttons / cards / links, electric arcs jump from the cursor to the edge of the element.
 * - Clicking fires a burst of bolts and a shock ring.
 *
 * Nothing runs on phones / tablets (touch) and the loop sleeps when the mouse is idle outside
 * the window, so it costs nothing when it is not visible.
 */

const MEDIA = '(min-width: 1024px) and (hover: hover) and (pointer: fine)';
const REDUCED = '(prefers-reduced-motion: reduce)';
const INTERACTIVE =
  'a, button, [role="button"], .feature-card, .resource-item, .version-item, .version-btn, .modal-close, .back-btn, summary, label, select, input[type="range"], input[type="checkbox"]';

type Pt = { x: number; y: number };
type Bolt = { pts: Pt[]; born: number; life: number; w: number };
type Ring = { x: number; y: number; born: number };

const CYAN = '157, 184, 255'; // #9DB8FF (site light blue)
const SKY = '111, 155, 255'; // #6F9BFF (site lightning blue)
const BLUE = '58, 99, 214'; // #3A63D6

function jag(out: Pt[], a: Pt, b: Pt, d: number, depth: number) {
  if (depth === 0) {
    out.push(b);
    return;
  }
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const len = Math.hypot(dx, dy) || 1;
  const off = (Math.random() - 0.5) * d;
  const m = { x: (a.x + b.x) / 2 + (-dy / len) * off, y: (a.y + b.y) / 2 + (dx / len) * off };
  jag(out, a, m, d * 0.58, depth - 1);
  jag(out, m, b, d * 0.58, depth - 1);
}

function makeBolt(a: Pt, b: Pt, disp: number, depth = 4): Pt[] {
  const out: Pt[] = [a];
  jag(out, a, b, disp, depth);
  return out;
}

function strokePath(ctx: CanvasRenderingContext2D, pts: Pt[], alpha: number, w: number) {
  if (pts.length < 2 || alpha <= 0.01) return;
  const passes: [number, string][] = [
    [w * 5, `rgba(${BLUE}, ${0.16 * alpha})`],
    [w * 2.6, `rgba(${SKY}, ${0.42 * alpha})`],
    [w * 1.1, `rgba(${CYAN}, ${0.9 * alpha})`],
    [w * 0.45, `rgba(255, 255, 255, ${alpha})`],
  ];
  ctx.lineJoin = 'round';
  ctx.lineCap = 'round';
  for (const [lw, col] of passes) {
    ctx.lineWidth = lw;
    ctx.strokeStyle = col;
    ctx.beginPath();
    ctx.moveTo(pts[0].x, pts[0].y);
    for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i].x, pts[i].y);
    ctx.stroke();
  }
}

export const LightningCursor: React.FC = () => {
  const canvasRef = React.useRef<HTMLCanvasElement>(null);

  React.useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const mq = window.matchMedia(MEDIA);
    const rm = window.matchMedia(REDUCED);
    const html = document.documentElement;

    let enabled = false;
    let raf = 0;
    let running = false;
    let w = 0;
    let h = 0;
    let dpr = 1;

    const mouse = { x: -100, y: -100, inside: false, seen: false };
    let trail: (Pt & { t: number })[] = [];
    let bolts: Bolt[] = [];
    let rings: Ring[] = [];
    let hoverEl: Element | null = null;
    let overText = false;
    let speed = 0;
    let lastMoveX = 0;
    let lastMoveY = 0;
    let lastIdleArc = 0;
    let lastHoverArc = 0;
    let headScale = 1;

    const resize = () => {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = window.innerWidth;
      h = window.innerHeight;
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px';
      canvas.style.height = h + 'px';
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    const addBolt = (a: Pt, b: Pt, life: number, w0: number, disp?: number) => {
      const d = disp ?? Math.hypot(b.x - a.x, b.y - a.y) * 0.45;
      bolts.push({ pts: makeBolt(a, b, d), born: performance.now(), life, w: w0 });
      if (bolts.length > 40) bolts.splice(0, bolts.length - 40);
    };

    const start = () => {
      if (running || !enabled) return;
      running = true;
      raf = requestAnimationFrame(frame);
    };

    const drawHead = (t: number) => {
      const { x, y } = mouse;
      const pulse = 0.85 + 0.15 * Math.sin(t / 90);
      const target = hoverEl ? 1.3 : 1;
      headScale += (target - headScale) * 0.2;
      const s = headScale;

      // soft aura (sits on the body of the bolt, just behind the tip)
      const r = 30 * s * pulse;
      const ax = x + 5 * s;
      const ay = y + 11 * s;
      const g = ctx.createRadialGradient(ax, ay, 0, ax, ay, r);
      g.addColorStop(0, `rgba(${CYAN}, 0.55)`);
      g.addColorStop(0.45, `rgba(${SKY}, 0.2)`);
      g.addColorStop(1, `rgba(${BLUE}, 0)`);
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(ax, ay, r, 0, Math.PI * 2);
      ctx.fill();

      // bolt shape: the TIP is exactly at the pointer (0,0) like a normal arrow cursor,
      // the body goes down-right. Clicks land on the tip.
      ctx.save();
      ctx.translate(x, y);
      ctx.scale(s, s);
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(11, 14);
      ctx.lineTo(5.5, 14);
      ctx.lineTo(9, 24);
      ctx.lineTo(-2.5, 8.5);
      ctx.lineTo(3.3, 8.5);
      ctx.closePath();
      ctx.lineJoin = 'round';
      ctx.lineWidth = 5;
      ctx.strokeStyle = `rgba(${SKY}, 0.35)`;
      ctx.stroke();
      ctx.lineWidth = 2;
      ctx.strokeStyle = `rgba(${CYAN}, 0.95)`;
      ctx.stroke();
      const fill = ctx.createLinearGradient(0, 0, 0, 24);
      fill.addColorStop(0, '#ffffff');
      fill.addColorStop(1, '#C4D5FF');
      ctx.fillStyle = fill;
      ctx.fill();
      ctx.restore();
    };

    const frame = (t: number) => {
      raf = 0;
      ctx.clearRect(0, 0, w, h);
      ctx.globalCompositeOperation = 'lighter';

      // drop old trail points
      trail = trail.filter((p) => t - p.t < 280);

      // speed (px per frame, smoothed)
      const dx = mouse.x - lastMoveX;
      const dy = mouse.y - lastMoveY;
      speed = speed * 0.8 + Math.hypot(dx, dy) * 0.2;
      lastMoveX = mouse.x;
      lastMoveY = mouse.y;

      // ---- trail: one jagged bolt from the pointer back through the recent path ----
      if (mouse.inside && trail.length > 1) {
        const path: Pt[] = [{ x: mouse.x, y: mouse.y }];
        for (let i = trail.length - 1; i >= 0; i--) path.push(trail[i]);
        const total = path.length - 1;
        for (let i = 0; i < total; i++) {
          const a = path[i];
          const b = path[i + 1];
          const k = i / total; // 0 = at pointer, 1 = tail
          const fade = 1 - k;
          const seg = makeBolt(a, b, Math.min(26, 5 + speed * 1.3) * (0.4 + fade * 0.8), 2);
          strokePath(ctx, seg, fade * 0.95, 1.5 * (0.35 + fade * 0.65));
        }

        // fork small branches off the trail while moving
        if (speed > 5 && Math.random() < 0.4) {
          const p = trail[Math.floor(Math.random() * trail.length)];
          const ang = Math.random() * Math.PI * 2;
          const len = 24 + Math.random() * 46;
          addBolt(p, { x: p.x + Math.cos(ang) * len, y: p.y + Math.sin(ang) * len }, 150, 0.8, len * 0.5);
        }
      }

      // ---- idle crackle around the head ----
      if (mouse.inside && t - lastIdleArc > 110) {
        lastIdleArc = t;
        const ang = Math.random() * Math.PI * 2;
        const len = 16 + Math.random() * 20;
        addBolt(
          { x: mouse.x, y: mouse.y },
          { x: mouse.x + Math.cos(ang) * len, y: mouse.y + Math.sin(ang) * len },
          110,
          0.7,
          len * 0.55
        );
      }

      // ---- arcs that jump to the edge of the hovered button / card ----
      if (mouse.inside && hoverEl && t - lastHoverArc > 65) {
        lastHoverArc = t;
        const r = hoverEl.getBoundingClientRect();
        if (r.width > 0 && r.height > 0) {
          const side = Math.floor(Math.random() * 4);
          const u = Math.random();
          const px = side === 0 ? r.left + u * r.width : side === 1 ? r.right : side === 2 ? r.left + u * r.width : r.left;
          const py = side === 0 ? r.top : side === 1 ? r.top + u * r.height : r.bottom;
          const dist = Math.hypot(px - mouse.x, py - mouse.y);
          if (dist < 190) {
            addBolt({ x: mouse.x, y: mouse.y }, { x: px, y: py }, 120, 0.9, dist * 0.4);
          }
        }
      }

      // ---- bolts (branches, arcs, click bursts) ----
      bolts = bolts.filter((b) => t - b.born < b.life);
      for (const b of bolts) {
        const age = (t - b.born) / b.life;
        const flicker = 0.65 + Math.random() * 0.35;
        strokePath(ctx, b.pts, (1 - age) * flicker, b.w);
      }

      // ---- click shock rings ----
      rings = rings.filter((r) => t - r.born < 360);
      for (const r of rings) {
        const k = (t - r.born) / 360;
        ctx.lineWidth = 2.2 * (1 - k) + 0.4;
        ctx.strokeStyle = `rgba(${CYAN}, ${0.75 * (1 - k)})`;
        ctx.beginPath();
        ctx.arc(r.x, r.y, 6 + k * 58, 0, Math.PI * 2);
        ctx.stroke();
      }

      // ---- head ----
      if (mouse.inside && mouse.seen && !overText) drawHead(t);

      ctx.globalCompositeOperation = 'source-over';

      // keep running while the mouse is in the window or something is still fading out
      if (mouse.inside || bolts.length || rings.length || trail.length) {
        raf = requestAnimationFrame(frame);
      } else {
        running = false;
        ctx.clearRect(0, 0, w, h);
      }
    };

    const onMove = (e: MouseEvent) => {
      mouse.x = e.clientX;
      mouse.y = e.clientY;
      mouse.inside = true;
      mouse.seen = true;
      const last = trail[trail.length - 1];
      if (!last || Math.hypot(last.x - e.clientX, last.y - e.clientY) > 5) {
        trail.push({ x: e.clientX, y: e.clientY, t: performance.now() });
        if (trail.length > 26) trail.shift();
      }
      const target = e.target as Element | null;
      hoverEl = target && target.closest ? target.closest(INTERACTIVE) : null;
      overText = !!(target && target.closest && target.closest('textarea, input[type="text"], input[type="password"], input[type="search"], input[type="url"], input[type="email"], input[type="number"], [contenteditable="true"]'));
      start();
    };

    const onDown = (e: MouseEvent) => {
      const c = { x: e.clientX, y: e.clientY };
      const n = 9;
      const base = Math.random() * Math.PI * 2;
      for (let i = 0; i < n; i++) {
        const ang = base + (i / n) * Math.PI * 2 + (Math.random() - 0.5) * 0.4;
        const len = 46 + Math.random() * 78;
        addBolt(c, { x: c.x + Math.cos(ang) * len, y: c.y + Math.sin(ang) * len }, 260, 1.15, len * 0.5);
      }
      rings.push({ x: c.x, y: c.y, born: performance.now() });
      start();
    };

    const onLeave = () => {
      mouse.inside = false;
      hoverEl = null;
      start();
    };
    const onEnter = (e: MouseEvent) => {
      mouse.x = e.clientX;
      mouse.y = e.clientY;
      mouse.inside = true;
    };

    const onVis = () => {
      if (document.hidden) {
        mouse.inside = false;
        bolts = [];
        trail = [];
        rings = [];
      }
    };

    const enable = () => {
      if (enabled) return;
      enabled = true;
      resize();
      html.classList.add('lightning-cursor-on');
      window.addEventListener('resize', resize);
      window.addEventListener('mousemove', onMove, { passive: true });
      window.addEventListener('mousedown', onDown, { passive: true });
      document.documentElement.addEventListener('mouseleave', onLeave);
      document.documentElement.addEventListener('mouseenter', onEnter);
      document.addEventListener('visibilitychange', onVis);
    };

    const disable = () => {
      if (!enabled) return;
      enabled = false;
      html.classList.remove('lightning-cursor-on');
      window.removeEventListener('resize', resize);
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mousedown', onDown);
      document.documentElement.removeEventListener('mouseleave', onLeave);
      document.documentElement.removeEventListener('mouseenter', onEnter);
      document.removeEventListener('visibilitychange', onVis);
      cancelAnimationFrame(raf);
      running = false;
      trail = [];
      bolts = [];
      rings = [];
      ctx.clearRect(0, 0, canvas.width, canvas.height);
    };

    const sync = () => {
      if (mq.matches && !rm.matches) enable();
      else disable();
    };
    sync();
    mq.addEventListener('change', sync);
    rm.addEventListener('change', sync);

    return () => {
      mq.removeEventListener('change', sync);
      rm.removeEventListener('change', sync);
      disable();
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      style={{
        position: 'fixed',
        inset: 0,
        width: '100%',
        height: '100%',
        pointerEvents: 'none',
        zIndex: 2147483646,
      }}
    />
  );
};

export default LightningCursor;
