import React from 'react';

// Shared hook: scroll to the section + play a short highlight when the navbar fires an event
function useCardHighlight(eventName: string, targetId = 'resource-section') {
  const [isHighlighted, setIsHighlighted] = React.useState(false);

  React.useEffect(() => {
    let timer: ReturnType<typeof setTimeout>;
    let raf = 0;

    const handleSelect = (e?: Event) => {
      // The phone menu does its own (smoother) scrolling and only asks for the highlight
      if (!(e as CustomEvent | undefined)?.detail?.skipScroll) {
        document
          .getElementById(targetId)
          ?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }

      setIsHighlighted(false);
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        raf = requestAnimationFrame(() => {
          setIsHighlighted(true);
          clearTimeout(timer);
          timer = setTimeout(() => setIsHighlighted(false), 1400);
        });
      });
    };

    window.addEventListener(eventName, handleSelect);
    return () => {
      window.removeEventListener(eventName, handleSelect);
      clearTimeout(timer);
      cancelAnimationFrame(raf);
    };
  }, [eventName, targetId]);

  return isHighlighted;
}

// ============================================================================
// ULTRA-TRANSPARENT GLASSMORPHIC CARDS (100% UNIFIED CYBER ICE & CYAN THEME)
// Color: Electric Cyber Cyan (#00F2FE), Sky Ice (#38BDF8), Deep Sapphire (#0038FF)
// Background: High-transparency crystal frosted glass with backdrop blur
// ============================================================================

export const FreeWebsiteCard: React.FC = () => {
  const isHighlighted = useCardHighlight('select-free-web');

  return (
    <div 
      className={`feature-card card-resource animate-fade-in-up relative ${
        isHighlighted ? 'free-web-popping' : ''
      }`}
    >
      {/* Ribbon */}
      <span className="corner-ribbon"></span>
      
      {/* Animated Glowing Border */}
      <div className="border-wrapper">
        <div className="card-border-animation"></div>
      </div>
      
      <div className={`card-inner ${isHighlighted ? 'free-web-highlight-glow' : ''}`}>
        <div className="badge">100% Free</div>
        
        <h3 className="card-title">Free Website</h3>
        
        {/* Premium Loader: Free Website */}
        <div className="sec-loader" aria-hidden="true">
          <span className="sec-glow"></span>
          <span className="sec-pulse"></span>
          <span className="sec-pulse sec-pulse-2"></span>
          <svg className="sec-ring sec-ring-a" viewBox="0 0 100 100" fill="none">
            <circle cx="50" cy="50" r="48" stroke="rgba(0, 242, 254, 0.45)" strokeWidth="1" strokeDasharray="1.5 5.5" strokeLinecap="round"/>
            <circle cx="50" cy="2" r="2.4" fill="#00F2FE"/>
          </svg>
          <svg className="sec-ring sec-ring-b" viewBox="0 0 100 100" fill="none">
            <circle cx="50" cy="50" r="44" stroke="rgba(56, 189, 248, 0.65)" strokeWidth="1.4" strokeDasharray="26 70 12 60" strokeLinecap="round"/>
            <circle cx="50" cy="94" r="1.8" fill="#38BDF8"/>
          </svg>
          <svg className="sec-art" viewBox="0 0 100 110" fill="none">
            <defs>
              <linearGradient id="fwS" x1="0" y1="0" x2="100" y2="110" gradientUnits="userSpaceOnUse">
                <stop offset="0" stopColor="#00F2FE"/>
                <stop offset="1" stopColor="#38BDF8"/>
              </linearGradient>
              <linearGradient id="fwF" x1="0" y1="0" x2="0" y2="110" gradientUnits="userSpaceOnUse">
                <stop offset="0" stopColor="#00F2FE" stopOpacity="0.25"/>
                <stop offset="1" stopColor="#0038FF" stopOpacity="0.08"/>
              </linearGradient>
              <linearGradient id="fwShim" x1="0" y1="0" x2="1" y2="0">
                <stop offset="0" stopColor="#fff" stopOpacity="0"/>
                <stop offset="0.5" stopColor="#fff" stopOpacity="0.45"/>
                <stop offset="1" stopColor="#fff" stopOpacity="0"/>
              </linearGradient>
              <clipPath id="fwHero">
                <rect x="22" y="47" width="56" height="18" rx="4"/>
              </clipPath>
            </defs>
            <g className="fw-win fw-el">
              <rect x="12" y="20" width="76" height="70" rx="10" fill="url(#fwF)" stroke="url(#fwS)" strokeWidth="3"/>
              <path d="M13.5 38H86.5" stroke="rgba(0, 242, 254, 0.45)" strokeWidth="1.4"/>
              <circle cx="22" cy="29" r="2.3" fill="#fff" opacity="0.95"/>
              <circle cx="30" cy="29" r="2.3" fill="#fff" opacity="0.65"/>
              <circle cx="38" cy="29" r="2.3" fill="#fff" opacity="0.4"/>
              <rect x="47" y="25" width="30" height="8" rx="4" fill="rgba(255,255,255,0.16)"/>
              <rect x="22" y="47" width="56" height="18" rx="4" fill="rgba(0, 242, 254, 0.22)"/>
              <g clipPath="url(#fwHero)">
                <rect className="fw-shimmer" x="-30" y="47" width="30" height="18" fill="url(#fwShim)"/>
              </g>
              <rect className="fw-l1 fw-el" x="22" y="71" width="46" height="4.5" rx="2.25" fill="#fff" opacity="0.85"/>
              <rect className="fw-l2 fw-el" x="22" y="79" width="30" height="4.5" rx="2.25" fill="#fff" opacity="0.55"/>
              <path className="fw-cursor" d="M64 66l0 11 3-3 2.4 5.2 2-.9-2.4-5.1 4.4-.3z" fill="#fff" stroke="rgba(0, 26, 153, 0.35)" strokeWidth="1.2" strokeLinejoin="round"/>
            </g>
            <circle cx="82" cy="24" r="12" fill="rgba(0, 26, 153, 0.35)" stroke="url(#fwS)" strokeWidth="2.4"/>
            <circle cx="82" cy="24" r="12" fill="url(#fwF)"/>
            <path d="M70.5 24H93.5M73 17.5H91M73 30.5H91" stroke="rgba(255,255,255,0.55)" strokeWidth="1" fill="none"/>
            <ellipse className="fw-mer fw-el" cx="82" cy="24" rx="5.5" ry="11.6" stroke="#fff" strokeWidth="1.3" fill="none"/>
            <ellipse className="fw-mer fw-mer2 fw-el" cx="82" cy="24" rx="5.5" ry="11.6" stroke="rgba(0, 242, 254, 0.9)" strokeWidth="1.1" fill="none"/>
          </svg>
          <i className="sec-dot d1"></i>
          <i className="sec-dot d2"></i>
          <i className="sec-dot d3"></i>
          <i className="sec-dot d4"></i>
        </div>

        <a href="#" className="download-btn" id="viewBtn">
          <span>VIEW</span>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
            <circle cx="12" cy="12" r="3" />
          </svg>
        </a>
      </div>
    </div>
  );
};

export const ApkBuildingCard: React.FC = () => {
  const isHighlighted = useCardHighlight('select-apk-building');

  return (
    <div 
      className={`feature-card apk-card animate-fade-in-up relative ${
        isHighlighted ? 'free-web-popping' : ''
      }`} 
      style={{ animationDelay: '0.24s' }}
    >
      {/* Ribbon */}
      <span className="corner-ribbon"></span>
      
      {/* Animated Glowing Border */}
      <div className="border-wrapper">
        <div className="card-border-animation"></div>
      </div>
      
      <div className={`card-inner ${isHighlighted ? 'free-web-highlight-glow' : ''}`}>
        <div className="badge">100% Free</div>
        
        <h3 className="card-title">apk building</h3>
        
        {/* Premium Loader: APK Building */}
        <div className="sec-loader" aria-hidden="true">
          <span className="sec-glow"></span>
          <span className="sec-pulse"></span>
          <span className="sec-pulse sec-pulse-2"></span>
          <svg className="sec-ring sec-ring-a" viewBox="0 0 100 100" fill="none">
            <circle cx="50" cy="50" r="48" stroke="rgba(0, 242, 254, 0.45)" strokeWidth="1" strokeDasharray="1.5 5.5" strokeLinecap="round"/>
            <circle cx="50" cy="2" r="2.4" fill="#00F2FE"/>
          </svg>
          <svg className="sec-ring sec-ring-b" viewBox="0 0 100 100" fill="none">
            <circle cx="50" cy="50" r="44" stroke="rgba(56, 189, 248, 0.65)" strokeWidth="1.4" strokeDasharray="26 70 12 60" strokeLinecap="round"/>
            <circle cx="50" cy="94" r="1.8" fill="#38BDF8"/>
          </svg>
          <svg className="sec-art" viewBox="0 0 100 110" fill="none">
            <defs>
              <linearGradient id="apkS" x1="0" y1="0" x2="100" y2="110" gradientUnits="userSpaceOnUse">
                <stop offset="0" stopColor="#00F2FE"/>
                <stop offset="1" stopColor="#38BDF8"/>
              </linearGradient>
              <linearGradient id="apkF" x1="0" y1="0" x2="0" y2="110" gradientUnits="userSpaceOnUse">
                <stop offset="0" stopColor="#00F2FE" stopOpacity="0.25"/>
                <stop offset="1" stopColor="#0038FF" stopOpacity="0.08"/>
              </linearGradient>
            </defs>
            <g className="apk-cube apk-el">
              <path d="M50 28L78 43V74L50 90L22 74V43Z" fill="url(#apkF)" stroke="url(#apkS)" strokeWidth="3" strokeLinejoin="round"/>
              <path d="M50 28L78 43L50 58L22 43Z" fill="rgba(255,255,255,0.16)"/>
              <path d="M22 43L50 58L78 43M50 58V90" stroke="rgba(255,255,255,0.45)" strokeWidth="1.6" strokeLinejoin="round"/>
              <circle cx="36" cy="72" r="2.2" fill="#00F2FE"/>
              <circle cx="64" cy="72" r="2.2" fill="#38BDF8"/>
            </g>
            <g className="apk-arrow apk-el">
              <path d="M50 4V26M41 18L50 27L59 18" stroke="#fff" strokeWidth="4.4" strokeLinecap="round" strokeLinejoin="round"/>
            </g>
            <rect x="28" y="98" width="44" height="4.5" rx="2.25" fill="rgba(255,255,255,0.14)"/>
            <rect className="apk-fill apk-el" x="28" y="98" width="44" height="4.5" rx="2.25" fill="url(#apkS)"/>
          </svg>
          <i className="sec-dot d1"></i>
          <i className="sec-dot d2"></i>
          <i className="sec-dot d3"></i>
          <i className="sec-dot d4"></i>
        </div>

        <a href="version%20html/apk.html" className="download-btn" id="apkViewBtn">
          <span>VIEW</span>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
            <circle cx="12" cy="12" r="3" />
          </svg>
        </a>
      </div>
    </div>
  );
};

export const BotMakingCard: React.FC = () => {
  const isHighlighted = useCardHighlight('select-bot-card');

  return (
    <div 
      className={`feature-card bot-card animate-fade-in-up relative ${
        isHighlighted ? 'free-web-popping' : ''
      }`} 
      style={{ animationDelay: '0.27s' }}
    >
      {/* Ribbon */}
      <span className="corner-ribbon"></span>
      
      {/* Animated Glowing Border */}
      <div className="border-wrapper">
        <div className="card-border-animation"></div>
      </div>
      
      <div className={`card-inner ${isHighlighted ? 'free-web-highlight-glow' : ''}`}>
        <div className="badge">100% Free</div>
        
        <h3 className="card-title">Bot Making</h3>
        
        {/* Premium Loader: Bot Making */}
        <div className="sec-loader" aria-hidden="true">
          <span className="sec-glow"></span>
          <span className="sec-pulse"></span>
          <span className="sec-pulse sec-pulse-2"></span>
          <svg className="sec-ring sec-ring-a" viewBox="0 0 100 100" fill="none">
            <circle cx="50" cy="50" r="48" stroke="rgba(0, 242, 254, 0.45)" strokeWidth="1" strokeDasharray="1.5 5.5" strokeLinecap="round"/>
            <circle cx="50" cy="2" r="2.4" fill="#00F2FE"/>
          </svg>
          <svg className="sec-ring sec-ring-b" viewBox="0 0 100 100" fill="none">
            <circle cx="50" cy="50" r="44" stroke="rgba(56, 189, 248, 0.65)" strokeWidth="1.4" strokeDasharray="26 70 12 60" strokeLinecap="round"/>
            <circle cx="50" cy="94" r="1.8" fill="#38BDF8"/>
          </svg>
          <svg className="sec-art" viewBox="0 0 100 110" fill="none">
            <defs>
              <linearGradient id="botS" x1="0" y1="0" x2="100" y2="110" gradientUnits="userSpaceOnUse">
                <stop offset="0" stopColor="#00F2FE"/>
                <stop offset="1" stopColor="#38BDF8"/>
              </linearGradient>
              <linearGradient id="botF" x1="0" y1="0" x2="0" y2="110" gradientUnits="userSpaceOnUse">
                <stop offset="0" stopColor="#00F2FE" stopOpacity="0.25"/>
                <stop offset="1" stopColor="#0038FF" stopOpacity="0.08"/>
              </linearGradient>
            </defs>
            <g className="bot-body bot-el">
              <path d="M50 26V15" stroke="url(#botS)" strokeWidth="3" strokeLinecap="round"/>
              <circle className="bot-beacon bot-el" cx="50" cy="11" r="4.2" fill="#00F2FE"/>
              <rect x="14" y="42" width="8" height="16" rx="3.5" fill="url(#botS)"/>
              <rect x="78" y="42" width="8" height="16" rx="3.5" fill="url(#botS)"/>
              <rect x="22" y="26" width="56" height="48" rx="15" fill="url(#botF)" stroke="url(#botS)" strokeWidth="3"/>
              <rect x="29" y="33" width="42" height="34" rx="10" fill="rgba(0, 26, 153, 0.35)" opacity="0.9"/>
              <g className="bot-eyes bot-el">
                <rect className="bot-eye bot-el" x="37" y="41" width="7" height="11" rx="3.5" fill="#00F2FE"/>
                <rect className="bot-eye bot-el" x="56" y="41" width="7" height="11" rx="3.5" fill="#00F2FE"/>
              </g>
              <rect className="bot-bar b1 bot-el" x="37.1" y="55" width="3" height="8" rx="1.5" fill="#fff"/>
              <rect className="bot-bar b2 bot-el" x="42.8" y="55" width="3" height="8" rx="1.5" fill="#fff"/>
              <rect className="bot-bar b3 bot-el" x="48.5" y="55" width="3" height="8" rx="1.5" fill="#fff"/>
              <rect className="bot-bar b4 bot-el" x="54.2" y="55" width="3" height="8" rx="1.5" fill="#fff"/>
              <rect className="bot-bar b5 bot-el" x="59.9" y="55" width="3" height="8" rx="1.5" fill="#fff"/>
              <rect x="34" y="78" width="32" height="16" rx="8" fill="url(#botF)" stroke="url(#botS)" strokeWidth="2.4"/>
              <circle cx="50" cy="86" r="2.6" fill="#00F2FE"/>
            </g>
            <path className="bot-spark bot-el" d="M88 16v8M84 20h8" stroke="#fff" strokeWidth="2" strokeLinecap="round"/>
          </svg>
          <i className="sec-dot d1"></i>
          <i className="sec-dot d2"></i>
          <i className="sec-dot d3"></i>
          <i className="sec-dot d4"></i>
        </div>

        <a href="#" className="download-btn" id="botViewBtn">
          <span>VIEW</span>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
            <circle cx="12" cy="12" r="3" />
          </svg>
        </a>
      </div>
    </div>
  );
};

export const SecurityCard: React.FC = () => {
  return (
    <div className="feature-card security-card animate-fade-in-up" style={{ animationDelay: '0.29s' }}>
      {/* Ribbon */}
      <span className="corner-ribbon"></span>
      
      {/* Animated Glowing Border */}
      <div className="border-wrapper">
        <div className="card-border-animation"></div>
      </div>
      
      <div className="card-inner">
        <div className="badge">100% Free</div>
        
        <h3 className="card-title">security</h3>
        
        {/* Security Loader Animation */}
        <div className="sec-loader" aria-hidden="true">
          <span className="sec-glow"></span>
          <span className="sec-pulse"></span>
          <span className="sec-pulse sec-pulse-2"></span>

          <svg className="sec-ring sec-ring-a" viewBox="0 0 100 100" fill="none">
            <circle cx="50" cy="50" r="48" stroke="rgba(0, 242, 254, 0.45)" strokeWidth="1" strokeDasharray="1.5 5.5" strokeLinecap="round"/>
            <circle cx="50" cy="2" r="2.4" fill="#00F2FE"/>
          </svg>
          <svg className="sec-ring sec-ring-b" viewBox="0 0 100 100" fill="none">
            <circle cx="50" cy="50" r="44" stroke="rgba(56, 189, 248, 0.65)" strokeWidth="1.4" strokeDasharray="26 70 12 60" strokeLinecap="round"/>
            <circle cx="50" cy="94" r="1.8" fill="#38BDF8"/>
          </svg>

          <svg className="sec-shield-svg" viewBox="0 0 100 110" fill="none">
            <defs>
              <linearGradient id="secGStroke" x1="14" y1="8" x2="86" y2="102" gradientUnits="userSpaceOnUse">
                <stop offset="0" stopColor="#00F2FE"/>
                <stop offset="1" stopColor="#38BDF8"/>
              </linearGradient>
              <linearGradient id="secGFill" x1="50" y1="8" x2="50" y2="102" gradientUnits="userSpaceOnUse">
                <stop offset="0" stopColor="#00F2FE" stopOpacity="0.25"/>
                <stop offset="1" stopColor="#0038FF" stopOpacity="0.08"/>
              </linearGradient>
              <linearGradient id="secGBeam" x1="0" y1="-20" x2="0" y2="0" gradientUnits="userSpaceOnUse">
                <stop offset="0" stopColor="#00F2FE" stopOpacity="0"/>
                <stop offset="1" stopColor="#00F2FE" stopOpacity="0.65"/>
              </linearGradient>
              <radialGradient id="secGKey" cx="50" cy="63" r="16" gradientUnits="userSpaceOnUse">
                <stop offset="0" stopColor="#00F2FE" stopOpacity="0.65"/>
                <stop offset="1" stopColor="#00F2FE" stopOpacity="0"/>
              </radialGradient>
              <clipPath id="secClip">
                <path d="M50 8 C60 15 74 19 86 20 V52 C86 76 71 92 50 102 C29 92 14 76 14 52 V20 C26 19 40 15 50 8 Z"/>
              </clipPath>
            </defs>

            <path d="M50 8 C60 15 74 19 86 20 V52 C86 76 71 92 50 102 C29 92 14 76 14 52 V20 C26 19 40 15 50 8 Z" fill="url(#secGFill)"/>
            <g clipPath="url(#secClip)">
              <g stroke="rgba(0, 242, 254, 0.2)" strokeWidth="0.8">
                <path d="M14 32H86M14 46H86M14 60H86M14 74H86M14 88H86"/>
                <path d="M32 8V102M50 8V102M68 8V102"/>
              </g>
              <g className="sec-scan">
                <rect x="0" y="-20" width="100" height="20" fill="url(#secGBeam)"/>
                <rect x="0" y="-0.8" width="100" height="1.8" fill="#ffffff" opacity="0.95"/>
              </g>
            </g>
            <path className="sec-shield-line" d="M50 8 C60 15 74 19 86 20 V52 C86 76 71 92 50 102 C29 92 14 76 14 52 V20 C26 19 40 15 50 8 Z" stroke="url(#secGStroke)" strokeWidth="3" strokeLinejoin="round"/>

            <circle className="sec-keyglow" cx="50" cy="63" r="16" fill="url(#secGKey)"/>
            <g className="sec-lock">
              <path className="sec-shackle" d="M42 54V47a8 8 0 0 1 16 0V54" stroke="#ffffff" strokeWidth="3.6" strokeLinecap="round" fill="none"/>
              <rect x="37" y="54" width="26" height="21" rx="5" fill="#ffffff"/>
              <circle cx="50" cy="63" r="3" fill="rgba(0, 26, 153, 0.35)"/>
              <rect x="48.8" y="64" width="2.4" height="6" rx="1.2" fill="rgba(0, 26, 153, 0.35)"/>
            </g>
          </svg>

          <i className="sec-dot d1"></i>
          <i className="sec-dot d2"></i>
          <i className="sec-dot d3"></i>
          <i className="sec-dot d4"></i>
        </div>
        
        <a href="#" className="download-btn" id="securityViewBtn">
          <span>VIEW</span>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
            <circle cx="12" cy="12" r="3" />
          </svg>
        </a>
      </div>
    </div>
  );
};

export const ApiKeyCard: React.FC = () => {
  const isHighlighted = useCardHighlight('select-api-card', 'card-api');

  return (
    <div 
      className={`feature-card api-card animate-fade-in-up relative ${
        isHighlighted ? 'free-web-popping' : ''
      }`} 
      style={{ animationDelay: '0.31s' }}
    >
      {/* Ribbon */}
      <span className="corner-ribbon"></span>

      {/* Animated Glowing Border */}
      <div className="border-wrapper">
        <div className="card-border-animation"></div>
      </div>

      <div className={`card-inner ${isHighlighted ? 'free-web-highlight-glow' : ''}`}>
        <div className="badge">100% Free</div>

        <h3 className="card-title">api key</h3>

        {/* Premium Loader: API Key */}
        <div className="sec-loader" aria-hidden="true">
          <span className="sec-glow"></span>
          <span className="sec-pulse"></span>
          <span className="sec-pulse sec-pulse-2"></span>
          <svg className="sec-ring sec-ring-a" viewBox="0 0 100 100" fill="none">
            <circle cx="50" cy="50" r="48" stroke="rgba(0, 242, 254, 0.45)" strokeWidth="1" strokeDasharray="1.5 5.5" strokeLinecap="round"/>
            <circle cx="50" cy="2" r="2.4" fill="#00F2FE"/>
          </svg>
          <svg className="sec-ring sec-ring-b" viewBox="0 0 100 100" fill="none">
            <circle cx="50" cy="50" r="44" stroke="rgba(56, 189, 248, 0.65)" strokeWidth="1.4" strokeDasharray="26 70 12 60" strokeLinecap="round"/>
            <circle cx="50" cy="94" r="1.8" fill="#38BDF8"/>
          </svg>
          <svg className="sec-art" viewBox="0 0 100 110" fill="none">
            <defs>
              <linearGradient id="apS" x1="18" y1="14" x2="82" y2="90" gradientUnits="userSpaceOnUse">
                <stop offset="0" stopColor="#00F2FE"/>
                <stop offset="1" stopColor="#38BDF8"/>
              </linearGradient>
              <linearGradient id="apF" x1="0" y1="14" x2="0" y2="90" gradientUnits="userSpaceOnUse">
                <stop offset="0" stopColor="#00F2FE" stopOpacity="0.25"/>
                <stop offset="1" stopColor="#0038FF" stopOpacity="0.10"/>
              </linearGradient>
              <linearGradient id="apK" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0" stopColor="#ffffff"/>
                <stop offset="1" stopColor="#00F2FE"/>
              </linearGradient>
              <linearGradient id="apTr" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0" stopColor="#00F2FE"/>
                <stop offset="1" stopColor="#38BDF8"/>
              </linearGradient>
              <linearGradient id="apShine" x1="0" y1="0" x2="1" y2="0">
                <stop offset="0" stopColor="#fff" stopOpacity="0"/>
                <stop offset="0.5" stopColor="#fff" stopOpacity="0.38"/>
                <stop offset="1" stopColor="#fff" stopOpacity="0"/>
              </linearGradient>
              <radialGradient id="apAura" cx="50%" cy="50%" r="50%">
                <stop offset="0" stopColor="#00F2FE" stopOpacity="0.55"/>
                <stop offset="0.6" stopColor="#38BDF8" stopOpacity="0.16"/>
                <stop offset="1" stopColor="#38BDF8" stopOpacity="0"/>
              </radialGradient>
              <clipPath id="apClip">
                <polygon points="50,14 82,33 82,71 50,90 18,71 18,33"/>
              </clipPath>
            </defs>

            <g transform="translate(0 3)">
              {/* soft aura */}
              <circle className="api-aura" cx="50" cy="52" r="46" fill="url(#apAura)"/>

              {/* hexagon badge */}
              <polygon points="50,14 82,33 82,71 50,90 18,71 18,33" fill="url(#apF)"/>
              <polygon points="50,14 82,33 82,71 50,90 18,71 18,33" fill="none" stroke="url(#apS)" strokeWidth="2.4" strokeLinejoin="round" opacity="0.55"/>
              <polygon points="50,21 76,36 76,68 50,83 24,68 24,36" fill="none" stroke="rgba(0, 242, 254, 0.22)" strokeWidth="1" strokeLinejoin="round"/>

              {/* rotating trace light */}
              <path className="api-trace-glow" d="M50 14 L82 33 L82 71 L50 90 L18 71 L18 33 Z" pathLength="100" stroke="#00F2FE" strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round"/>
              <path className="api-trace" d="M50 14 L82 33 L82 71 L50 90 L18 71 L18 33 Z" pathLength="100" stroke="url(#apTr)" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round"/>

              {/* shine swipe */}
              <g clipPath="url(#apClip)">
                <polygon className="api-shine" points="14,10 30,10 22,94 6,94" fill="url(#apShine)"/>
              </g>

              {/* key */}
              <g transform="rotate(45 50 52)">
                <circle cx="38" cy="52" r="10" fill="none" stroke="url(#apK)" strokeWidth="4.2"/>
                <circle cx="38" cy="52" r="3" fill="#00F2FE"/>
                <rect x="47" y="49.4" width="26" height="5.2" rx="2.6" fill="url(#apK)"/>
                <rect x="61" y="54" width="5" height="8.5" rx="2" fill="url(#apK)"/>
                <rect x="68" y="54" width="5" height="12" rx="2" fill="#00F2FE"/>
              </g>
              {/* glint */}
              <path className="api-key-glint api-el" d="M63 32 L64.4 36.6 L69 38 L64.4 39.4 L63 44 L61.6 39.4 L57 38 L61.6 36.6 Z" fill="#fff"/>

              {/* request in */}
              <line x1="3" y1="52" x2="17" y2="52" stroke="rgba(0, 242, 254, 0.35)" strokeWidth="1.5" strokeLinecap="round"/>
              <circle className="api-pkt api-in i1 api-el" cx="4" cy="52" r="2.3" fill="#00F2FE"/>
              <circle className="api-pkt api-in i2 api-el" cx="4" cy="52" r="2.3" fill="#38BDF8"/>
              {/* response out */}
              <line x1="83" y1="52" x2="97" y2="52" stroke="rgba(0, 242, 254, 0.35)" strokeWidth="1.5" strokeLinecap="round"/>
              <circle className="api-pkt api-out o1 api-el" cx="84" cy="52" r="2.3" fill="#fff"/>
              <circle className="api-pkt api-out o2 api-el" cx="84" cy="52" r="2.3" fill="#00F2FE"/>
            </g>
          </svg>
          <i className="sec-dot d1"></i>
          <i className="sec-dot d2"></i>
          <i className="sec-dot d3"></i>
          <i className="sec-dot d4"></i>
        </div>

        <a href="version%20html/api.html" className="download-btn" id="apiViewBtn">
          <span>VIEW</span>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
            <circle cx="12" cy="12" r="3" />
          </svg>
        </a>
      </div>
    </div>
  );
};

export const ReviewProjectCard: React.FC = () => {
  const isHighlighted = useCardHighlight('select-review-card', 'card-review');

  return (
    <div 
      className={`feature-card review-card animate-fade-in-up relative ${
        isHighlighted ? 'free-web-popping' : ''
      }`} 
      style={{ animationDelay: '0.29s' }}
    >
      {/* Ribbon */}
      <span className="corner-ribbon"></span>
      
      {/* Animated Glowing Border */}
      <div className="border-wrapper">
        <div className="card-border-animation"></div>
      </div>
      
      <div className={`card-inner ${isHighlighted ? 'free-web-highlight-glow' : ''}`}>
        <div className="badge">100% Free</div>
        
        <h3 className="card-title">review project</h3>
        
        {/* Premium Loader: Review Project */}
        <div className="sec-loader" aria-hidden="true">
          <span className="sec-glow"></span>
          <span className="sec-pulse"></span>
          <span className="sec-pulse sec-pulse-2"></span>
          <svg className="sec-ring sec-ring-a" viewBox="0 0 100 100" fill="none">
            <circle cx="50" cy="50" r="48" stroke="rgba(0, 242, 254, 0.45)" strokeWidth="1" strokeDasharray="1.5 5.5" strokeLinecap="round"/>
            <circle cx="50" cy="2" r="2.4" fill="#00F2FE"/>
          </svg>
          <svg className="sec-ring sec-ring-b" viewBox="0 0 100 100" fill="none">
            <circle cx="50" cy="50" r="44" stroke="rgba(56, 189, 248, 0.65)" strokeWidth="1.4" strokeDasharray="26 70 12 60" strokeLinecap="round"/>
            <circle cx="50" cy="94" r="1.8" fill="#38BDF8"/>
          </svg>
          <svg className="sec-art" viewBox="0 0 100 110" fill="none">
            <defs>
              <linearGradient id="rvS" x1="0" y1="0" x2="100" y2="110" gradientUnits="userSpaceOnUse">
                <stop offset="0" stopColor="#00F2FE"/>
                <stop offset="1" stopColor="#38BDF8"/>
              </linearGradient>
              <linearGradient id="rvF" x1="0" y1="0" x2="0" y2="110" gradientUnits="userSpaceOnUse">
                <stop offset="0" stopColor="#00F2FE" stopOpacity="0.25"/>
                <stop offset="1" stopColor="#0038FF" stopOpacity="0.08"/>
              </linearGradient>
            </defs>
            <rect x="20" y="12" width="52" height="72" rx="8" fill="url(#rvF)" stroke="url(#rvS)" strokeWidth="3"/>
            <rect x="29" y="22" width="20" height="4.5" rx="2.25" fill="#00F2FE"/>
            <rect className="rv-line l1" x="29" y="32" width="34" height="3.6" rx="1.8" fill="#fff" opacity="0.85"/>
            <rect className="rv-line l2" x="29" y="40" width="28" height="3.6" rx="1.8" fill="#fff" opacity="0.85"/>
            <rect className="rv-line l3" x="29" y="48" width="32" height="3.6" rx="1.8" fill="#fff" opacity="0.85"/>
            {/* Unified Cyber Cyan Stars */}
            <g transform="translate(35 68)">
              <polygon className="rv-star s1 rv-el" points="0.00,-5.20 1.29,-1.78 4.95,-1.61 2.09,0.68 3.06,4.21 0.00,2.20 -3.06,4.21 -2.09,0.68 -4.95,-1.61 -1.29,-1.78" fill="#00F2FE"/>
            </g>
            <g transform="translate(46 68)">
              <polygon className="rv-star s2 rv-el" points="0.00,-5.20 1.29,-1.78 4.95,-1.61 2.09,0.68 3.06,4.21 0.00,2.20 -3.06,4.21 -2.09,0.68 -4.95,-1.61 -1.29,-1.78" fill="#00F2FE"/>
            </g>
            <g transform="translate(57 68)">
              <polygon className="rv-star s3 rv-el" points="0.00,-5.20 1.29,-1.78 4.95,-1.61 2.09,0.68 3.06,4.21 0.00,2.20 -3.06,4.21 -2.09,0.68 -4.95,-1.61 -1.29,-1.78" fill="#00F2FE"/>
            </g>
            <g className="rv-check rv-el">
              <circle cx="26" cy="86" r="11" fill="rgba(0, 26, 153, 0.35)" stroke="url(#rvS)" strokeWidth="2.4"/>
              <circle cx="26" cy="86" r="11" fill="url(#rvF)"/>
              <path d="M20.5 86.2l4 4 7.2-8" stroke="#00F2FE" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
            </g>
            <g className="rv-glass rv-el">
              <circle cx="72" cy="66" r="14" fill="rgba(0, 242, 254, 0.18)" stroke="#38BDF8" strokeWidth="3.5"/>
              <path d="M62.5 58.5a11 11 0 0 1 8-4" stroke="rgba(255,255,255,0.7)" strokeWidth="2" strokeLinecap="round"/>
              <path d="M82.5 76.5L94 88" stroke="#38BDF8" strokeWidth="5.5" strokeLinecap="round"/>
            </g>
          </svg>
          <i className="sec-dot d1"></i>
          <i className="sec-dot d2"></i>
          <i className="sec-dot d3"></i>
          <i className="sec-dot d4"></i>
        </div>
        
        <a href="#" className="download-btn" id="reviewViewBtn">
          <span>VIEW</span>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
            <circle cx="12" cy="12" r="3" />
          </svg>
        </a>
      </div>
    </div>
  );
};

export const PcToolsCard: React.FC = () => {
  const isHighlighted = useCardHighlight('select-pctools-card', 'card-pctools');

  return (
    <div 
      className={`feature-card pctools-card animate-fade-in-up relative ${
        isHighlighted ? 'free-web-popping' : ''
      }`} 
      style={{ animationDelay: '0.33s' }}
    >
      {/* Ribbon */}
      <span className="corner-ribbon"></span>
      
      {/* Animated Glowing Border */}
      <div className="border-wrapper">
        <div className="card-border-animation"></div>
      </div>
      
      <div className={`card-inner ${isHighlighted ? 'free-web-highlight-glow' : ''}`}>
        <div className="badge">100% Free</div>
        
        <h3 className="card-title">PC Tools</h3>
        
        {/* Premium Loader: PC Tools */}
        <div className="sec-loader" aria-hidden="true">
          <span className="sec-glow"></span>
          <span className="sec-pulse"></span>
          <span className="sec-pulse sec-pulse-2"></span>
          <svg className="sec-ring sec-ring-a" viewBox="0 0 100 100" fill="none">
            <circle cx="50" cy="50" r="48" stroke="rgba(0, 242, 254, 0.45)" strokeWidth="1" strokeDasharray="1.5 5.5" strokeLinecap="round"/>
            <circle cx="50" cy="2" r="2.4" fill="#00F2FE"/>
          </svg>
          <svg className="sec-ring sec-ring-b" viewBox="0 0 100 100" fill="none">
            <circle cx="50" cy="50" r="44" stroke="rgba(56, 189, 248, 0.65)" strokeWidth="1.4" strokeDasharray="26 70 12 60" strokeLinecap="round"/>
            <circle cx="50" cy="94" r="1.8" fill="#38BDF8"/>
          </svg>
          <svg className="sec-art" viewBox="0 0 100 110" fill="none">
            <defs>
              <linearGradient id="pcS" x1="0" y1="0" x2="100" y2="110" gradientUnits="userSpaceOnUse">
                <stop offset="0" stopColor="#00F2FE"/>
                <stop offset="1" stopColor="#38BDF8"/>
              </linearGradient>
              <linearGradient id="pcF" x1="0" y1="0" x2="0" y2="110" gradientUnits="userSpaceOnUse">
                <stop offset="0" stopColor="#00F2FE" stopOpacity="0.25"/>
                <stop offset="1" stopColor="#0038FF" stopOpacity="0.08"/>
              </linearGradient>
              <linearGradient id="pcShim" x1="0" y1="0" x2="1" y2="0">
                <stop offset="0" stopColor="#fff" stopOpacity="0"/>
                <stop offset="0.5" stopColor="#fff" stopOpacity="0.4"/>
                <stop offset="1" stopColor="#fff" stopOpacity="0"/>
              </linearGradient>
              <clipPath id="pcScreen">
                <rect x="20" y="28" width="60" height="38" rx="3"/>
              </clipPath>
            </defs>
            <g className="pc-body pc-el">
              {/* monitor */}
              <rect x="12" y="20" width="76" height="54" rx="8" fill="url(#pcF)" stroke="url(#pcS)" strokeWidth="3"/>
              <rect x="20" y="28" width="60" height="38" rx="3" fill="rgba(0, 26, 153, 0.35)"/>
              <g clipPath="url(#pcScreen)">
                <rect className="pc-shimmer" x="-30" y="28" width="30" height="38" fill="url(#pcShim)"/>
              </g>
              {/* code lines typing */}
              <rect className="pc-line l1 pc-el" x="26" y="35" width="30" height="3.4" rx="1.7" fill="#00F2FE"/>
              <rect className="pc-line l2 pc-el" x="26" y="43" width="42" height="3.4" rx="1.7" fill="#fff" opacity="0.85"/>
              <rect className="pc-line l3 pc-el" x="26" y="51" width="24" height="3.4" rx="1.7" fill="#fff" opacity="0.6"/>
              <rect className="pc-cursor pc-el" x="53" y="50" width="3" height="6" rx="1" fill="#00F2FE"/>
              {/* stand */}
              <path d="M44 74V84M56 74V84" stroke="url(#pcS)" strokeWidth="3" strokeLinecap="round"/>
              <rect x="32" y="84" width="36" height="6" rx="3" fill="url(#pcF)" stroke="url(#pcS)" strokeWidth="2.4"/>
            </g>
            {/* spinning gear badge */}
            <circle cx="82" cy="78" r="15" fill="rgba(0, 26, 153, 0.55)" stroke="url(#pcS)" strokeWidth="2.4"/>
            <g className="pc-gear pc-el">
              <path d="M82 66.5V70M82 86V89.5M70.5 78H74M90 78H93.5M73.9 69.9L76.4 72.4M87.6 83.6L90.1 86.1M90.1 69.9L87.6 72.4M76.4 83.6L73.9 86.1" stroke="#fff" strokeWidth="3" strokeLinecap="round"/>
              <circle cx="82" cy="78" r="7.5" fill="url(#pcF)" stroke="#00F2FE" strokeWidth="2.4"/>
              <circle cx="82" cy="78" r="2.6" fill="#00F2FE"/>
            </g>
            <path className="pc-spark pc-el" d="M14 12v8M10 16h8" stroke="#fff" strokeWidth="2" strokeLinecap="round"/>
          </svg>
          <i className="sec-dot d1"></i>
          <i className="sec-dot d2"></i>
          <i className="sec-dot d3"></i>
          <i className="sec-dot d4"></i>
        </div>
        
        <a href="#" className="download-btn" id="pcToolsViewBtn">
          <span>VIEW</span>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
            <circle cx="12" cy="12" r="3" />
          </svg>
        </a>
      </div>
    </div>
  );
};

// ============================================================================
// MAIN RESOURCE SECTION COMPONENT
// Responsive layout:
// - Mobile: 1 card per row (stacked vertically in serial order 1 to 7)
// - Tablet: 2 cards per row (sm:grid-cols-2)
// - Desktop / PC: 4 cards per row (lg:grid-cols-4, cards 5-7 wrap to row 2)
// ============================================================================

// Phone-only separator between two sections: fading line, glowing diamond and two small dots
const SectionDivider: React.FC = () => (
  <div className="section-divider-diamond sm:hidden w-full" aria-hidden="true">
    <span className="sdd-line" />
    <span className="sdd-diamond" />
    <span className="sdd-dot sdd-dot-a" />
    <span className="sdd-dot sdd-dot-b" />
  </div>
);

export const ResourceSection: React.FC = () => {
  const sectionRef = React.useRef<HTMLElement>(null);

  // Toggle the data-inview attribute on cards (an attribute, not a class: React re-renders reset className and would wipe a class) near the viewport; CSS pauses all animations of cards without it
  React.useEffect(() => {
    const root = sectionRef.current;
    if (!root || typeof IntersectionObserver === 'undefined') {
      root?.querySelectorAll('.feature-card').forEach((el) => el.setAttribute('data-inview', ''));
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) e.target.toggleAttribute('data-inview', e.isIntersecting);
      },
      { rootMargin: '80px 0px' }
    );
    root.querySelectorAll('.feature-card').forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);

  return (
    <section ref={sectionRef} id="resource-section" className="w-full relative z-10 py-8 sm:py-12 px-4 sm:px-6 lg:px-8 scroll-mt-14 sm:scroll-mt-0">
      <div className="max-w-[1440px] mx-auto">
        
        {/* ===== PC only: heading above the six cards (hidden on phone / tablet) ===== */}
        <div className="pcs-section mpc-section">
          <div className="pcs-head">
            <h2 className="pcs-title">Mobile <em>and PC</em></h2>
            <p className="pcs-desc">
              Free tools for mobile and PC &ndash; watch the video guide, then download the main file.
            </p>
          </div>
        </div>

        {/* 
          Grid Container:
          - Phone: 1 card per row (grid-cols-1)
          - Tablet: 2 cards per row (sm:grid-cols-2)
          - PC / Desktop: Exactly 4 cards per row (lg:grid-cols-4) with generous spacing!
        */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-6 xl:gap-x-10 gap-y-12 justify-items-center">
          
          {/* 1. Category: Resource -> Free Website Card */}
          <div id="card-free-website" className="scroll-mt-28 w-full flex flex-col items-center">
            <div id="card-resource" className="flex flex-col items-center w-full scroll-mt-28">
              <div className="category-header">
                <h2>Resource</h2>
              </div>
              <FreeWebsiteCard />
            </div>
          </div>

          <SectionDivider />

          {/* 2. Category: Apk -> apk building Card */}
          <div id="card-apk" className="flex flex-col items-center w-full scroll-mt-24">
            <div className="category-header">
              <h2>Apk</h2>
            </div>
            <ApkBuildingCard />
          </div>

          <SectionDivider />

          {/* 3. Category: BOT -> Bot Making Card */}
          <div id="card-bot" className="flex flex-col items-center w-full scroll-mt-24">
            <div className="category-header">
              <h2>BOT</h2>
            </div>
            <BotMakingCard />
          </div>

          <SectionDivider />

          {/* 4. Category: Security -> security Card */}
          <div id="card-security" className="flex flex-col items-center w-full scroll-mt-24">
            <div className="category-header">
              <h2>Security</h2>
            </div>
            <SecurityCard />
          </div>

          <SectionDivider />

          {/* 5. Category: API -> api key Card */}
          <div id="card-api" className="flex flex-col items-center w-full scroll-mt-24">
            <div className="category-header">
              <h2>API</h2>
            </div>
            <ApiKeyCard />
          </div>

          <SectionDivider />

          {/* 6. Category: Review -> review project Card */}
          <div id="card-review" className="flex flex-col items-center w-full scroll-mt-24">
            <div className="category-header">
              <h2>Review</h2>
            </div>
            <ReviewProjectCard />
          </div>

        </div>

        {/* ===== Separate section 2: PC Tools (heading on top, only the PC Tools card below) ===== */}
        <div id="card-pctools" className="pcs-section scroll-mt-24">
          {/* Phone / tablet: unchanged */}
          <div className="pcs-head pcs-mobile-head">
            <div className="pcs-eyebrow"><span>Tools</span></div>
            <h2 className="pcs-title">PC <em>Tools</em></h2>
            <p className="pcs-desc">
              Free PC tools &ndash; watch the video guide, then download the main file.
            </p>
          </div>
          {/* PC only: small "Tools" category title above the card (same style as Resource / Apk / BOT ...) */}
          <div className="pcs-card-wrap">
            <div className="category-header pcs-pc-title">
              <h2>Tools</h2>
            </div>
            <PcToolsCard />
          </div>
        </div>

      </div>
    </section>
  );
};

export default ResourceSection;
