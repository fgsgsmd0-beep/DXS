import { useEffect, useRef, type CSSProperties, type ReactNode } from "react";

/**
 * Press and hold for 2 seconds (without moving) and the card lifts; while the finger stays down it
 * follows the finger anywhere on the screen, and on release it springs back to its place.
 * A normal swipe (page scroll) starts moving before 2s, which cancels the hold, so scrolling is untouched.
 */
export default function HoldDrag({ children, className, style, holdMs = 2000 }: {
  children: ReactNode; className?: string; style?: CSSProperties; holdMs?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    let timer = 0, active = false, id = -1, sx = 0, sy = 0, raf = 0, tx = 0, ty = 0;

    const apply = () => {
      raf = 0;
      el.style.transform = `translate3d(${tx}px, ${ty}px, 0) scale(1.04)`;
    };
    const find = (e: TouchEvent) => Array.from(e.touches).find(t => t.identifier === id) || null;

    const onStart = (e: TouchEvent) => {
      if (e.touches.length !== 1 || active) return;
      const t = e.touches[0];
      id = t.identifier; sx = t.clientX; sy = t.clientY;
      window.clearTimeout(timer);
      timer = window.setTimeout(() => {
        active = true; tx = 0; ty = 0;
        el.style.transition = "transform 0.18s ease-out, box-shadow 0.18s";
        el.classList.add("hd-lifted");
        el.style.transform = "translate3d(0,0,0) scale(1.04)";
        try { navigator.vibrate?.(25); } catch { /* not supported */ }
      }, holdMs);
    };
    const onMove = (e: TouchEvent) => {
      const t = find(e);
      if (!t) return;
      if (!active) {
        // finger moved before 2s: this is a scroll, not a hold
        if (Math.abs(t.clientX - sx) > 10 || Math.abs(t.clientY - sy) > 10) window.clearTimeout(timer);
        return;
      }
      if (e.cancelable) e.preventDefault();
      el.style.transition = "none";
      tx = t.clientX - sx; ty = t.clientY - sy;
      if (!raf) raf = requestAnimationFrame(apply);
    };
    const onEnd = () => {
      window.clearTimeout(timer);
      if (!active) return;
      active = false;
      if (raf) { cancelAnimationFrame(raf); raf = 0; }
      el.classList.remove("hd-lifted");
      el.style.transition = "transform 0.6s cubic-bezier(0.34, 1.56, 0.64, 1), box-shadow 0.4s";
      el.style.transform = "translate3d(0,0,0) scale(1)";
    };
    const noMenu = (e: Event) => e.preventDefault();

    el.addEventListener("touchstart", onStart, { passive: true });
    el.addEventListener("touchmove", onMove, { passive: false });
    el.addEventListener("touchend", onEnd);
    el.addEventListener("touchcancel", onEnd);
    el.addEventListener("contextmenu", noMenu);
    return () => {
      window.clearTimeout(timer);
      if (raf) cancelAnimationFrame(raf);
      el.removeEventListener("touchstart", onStart);
      el.removeEventListener("touchmove", onMove);
      el.removeEventListener("touchend", onEnd);
      el.removeEventListener("touchcancel", onEnd);
      el.removeEventListener("contextmenu", noMenu);
    };
  }, [holdMs]);

  return (
    <div ref={ref} className={className} style={{ ...style, WebkitTouchCallout: "none", WebkitUserSelect: "none", userSelect: "none", willChange: "transform", position: "relative", zIndex: 5 } as CSSProperties}>
      {children}
    </div>
  );
}
