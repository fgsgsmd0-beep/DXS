import { lazy, Suspense, useEffect, useSyncExternalStore } from "react";
import { Component } from "@/components/ui/hero";
import { PcBackground } from "@/components/ui/hero-odyssey";
import MobileScrollBar from "@/components/ui/mobile-scrollbar";
import LightningCursor from "@/components/ui/lightning-cursor";

// Cards are below the fold on phones, so their code (lots of inline SVG) loads in a separate chunk
const loadResources = () => import("@/components/ui/resource-section");
const ResourceSection = lazy(() =>
  loadResources().then((m) => ({ default: m.ResourceSection }))
);

// PC (>= 1024px): same breakpoint the hero uses for its PC layout
function useIsPC() {
  return useSyncExternalStore(
    (cb) => {
      const mq = window.matchMedia("(min-width: 1024px)");
      mq.addEventListener("change", cb);
      return () => mq.removeEventListener("change", cb);
    },
    () => window.matchMedia("(min-width: 1024px)").matches,
    () => false
  );
}

export default function Page() {
  const isPC = useIsPC();

  // Warm the chunk as soon as the browser is idle so the cards are ready before the user scrolls
  useEffect(() => {
    const w = window as Window & {
      requestIdleCallback?: (cb: () => void, opts?: { timeout: number }) => number;
    };
    if (w.requestIdleCallback) w.requestIdleCallback(() => void loadResources(), { timeout: 2000 });
    else setTimeout(() => void loadResources(), 800);
  }, []);

  return (
    <div className="w-full min-h-screen bg-black text-white flex flex-col relative overflow-x-hidden">
      {/* One fixed background (black + blue lightning) behind the WHOLE page on PC AND phone,
          so it keeps showing while scrolling and there is no cut line between sections.
          Phones render it at a lower resolution to stay smooth. */}
      <PcBackground compact={!isPC} />

      {/* PC only: lightning cursor (bolt pointer, electric trail, arcs on buttons, burst on click) */}
      {isPC && <LightningCursor />}

      {/* Phone / tablet: lightning scroll rail (PC uses the styled browser scroll bar, see index.css) */}
      {!isPC && <MobileScrollBar />}

      {/* Background grid spanning the page */}
      <div
        className="fixed inset-0 pointer-events-none z-0 opacity-[0.35]"
        style={{
          backgroundImage: `
            linear-gradient(to right, rgba(255, 255, 255, 0.08) 1px, transparent 1px),
            linear-gradient(to bottom, rgba(255, 255, 255, 0.08) 1px, transparent 1px)
          `,
          backgroundSize: "4rem 4rem",
        }}
      />

      {/* Hero (z-30 keeps the fixed mobile navbar above the cards) */}
      <div className="relative z-30">
        <Component />
      </div>

      {/* Cards (z-10 so they slide under the navbar) */}
      <div className="relative z-10 pb-16">
        <Suspense fallback={<div style={{ minHeight: "100vh" }} aria-hidden="true" />}>
          <ResourceSection />
        </Suspense>
      </div>
    </div>
  );
}
