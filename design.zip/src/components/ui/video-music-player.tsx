import React, { useState, useRef, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  RotateCcw,
  RotateCw,
  Repeat,
  X,
  Radio
} from 'lucide-react';

const VIDEO_URL = '/video.mp4';

export const DevYasinXPlayer = ({ compact = false, small = false, headless = false }: { compact?: boolean; small?: boolean; headless?: boolean }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(0.9);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(9);
  const [isLooping, setIsLooping] = useState(true);
  const [speed, setSpeed] = useState(1);

  const videoRef = useRef<HTMLVideoElement>(null);

  // ---- Video preload: download once in the background as soon as the site opens ----
  // blobRef holds the fully downloaded video; the Service Worker (public/sw.js) keeps a copy in
  // the browser cache so later visits don't download it again.
  const blobUrlRef = useRef<string | null>(null);
  const [videoSrc, setVideoSrc] = useState<string>(VIDEO_URL);

  useEffect(() => {
    let cancelled = false;
    const conn = (navigator as Navigator & {
      connection?: { saveData?: boolean; effectiveType?: string };
    }).connection;
    // Respect data-saver / 2G users
    if (conn?.saveData || /2g/.test(conn?.effectiveType || '')) return;

    const start = () => {
      fetch(VIDEO_URL)
        .then((r) => (r.ok ? r.blob() : Promise.reject(new Error('video fetch failed'))))
        .then((blob) => {
          if (cancelled) return;
          blobUrlRef.current = URL.createObjectURL(blob);
        })
        .catch(() => {
          /* falls back to normal streaming from /video.mp4 */
        });
    };
    // Start a few seconds after the page has loaded and the phone is idle, so the 2.7 MB download
    // never competes with first paint, the lightning shader or the first scroll.
    let delay = 0;
    let idle = 0;
    const w = window as Window & {
      requestIdleCallback?: (cb: () => void, o?: { timeout: number }) => number;
      cancelIdleCallback?: (id: number) => void;
    };
    const schedule = () => {
      delay = window.setTimeout(() => {
        if (w.requestIdleCallback) idle = w.requestIdleCallback(start, { timeout: 6000 });
        else start();
      }, 2500);
    };
    if (document.readyState === 'complete') schedule();
    else window.addEventListener('load', schedule, { once: true });

    return () => {
      cancelled = true;
      window.clearTimeout(delay);
      if (idle && w.cancelIdleCallback) w.cancelIdleCallback(idle);
      window.removeEventListener('load', schedule);
      if (blobUrlRef.current) {
        URL.revokeObjectURL(blobUrlRef.current);
        blobUrlRef.current = null;
      }
    };
  }, []);

  // ---- Lock the whole page while the player is open ----
  useEffect(() => {
    if (!isOpen) return;
    const html = document.documentElement;
    const body = document.body;
    const root = document.getElementById('root');
    const scrollY = window.scrollY;

    html.classList.add('modal-open');
    body.style.position = 'fixed';
    body.style.top = `-${scrollY}px`;
    body.style.left = '0';
    body.style.right = '0';
    body.style.width = '100%';
    body.style.overflow = 'hidden';
    // Nothing behind the player can be tapped, focused or read by screen readers
    root?.setAttribute('inert', '');
    root?.setAttribute('aria-hidden', 'true');

    return () => {
      html.classList.remove('modal-open');
      body.style.position = '';
      body.style.top = '';
      body.style.left = '';
      body.style.right = '';
      body.style.width = '';
      body.style.overflow = '';
      root?.removeAttribute('inert');
      root?.removeAttribute('aria-hidden');
      window.scrollTo(0, scrollY); // return to exactly where the visitor was
    };
  }, [isOpen]);

  // Single click: Open modal and immediately start playing video
  const handleBadgeClick = () => {
    setVideoSrc(blobUrlRef.current ?? VIDEO_URL);
    setIsOpen(true);
    setTimeout(() => {
      if (videoRef.current) {
        videoRef.current.currentTime = 0;
        videoRef.current.play().then(() => {
          setIsPlaying(true);
        }).catch((err) => {
          console.log("Autoplay policy handled:", err);
          setIsPlaying(false);
        });
      }
    }, 150);
  };

  const handleClose = () => {
    if (videoRef.current) {
      videoRef.current.pause();
    }
    setIsPlaying(false);
    setIsOpen(false);
  };

  const togglePlay = () => {
    if (!videoRef.current) return;
    if (videoRef.current.paused) {
      videoRef.current.play().then(() => setIsPlaying(true)).catch(console.error);
    } else {
      videoRef.current.pause();
      setIsPlaying(false);
    }
  };

  const toggleMute = () => {
    if (!videoRef.current) return;
    videoRef.current.muted = !isMuted;
    setIsMuted(!isMuted);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setVolume(val);
    if (videoRef.current) {
      videoRef.current.volume = val;
      videoRef.current.muted = val === 0;
      setIsMuted(val === 0);
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      const t = videoRef.current.currentTime;
      setCurrentTime((prev) => (Math.abs(prev - t) >= 0.1 ? t : prev));
    }
  };

  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      setDuration(videoRef.current.duration || 9);
      videoRef.current.volume = volume;
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const targetTime = parseFloat(e.target.value);
    setCurrentTime(targetTime);
    if (videoRef.current) {
      videoRef.current.currentTime = targetTime;
    }
  };

  const SPEEDS = [1, 1.25, 1.5, 2, 0.75];
  const cycleSpeed = () => {
    const next = SPEEDS[(SPEEDS.indexOf(speed) + 1) % SPEEDS.length];
    setSpeed(next);
    if (videoRef.current) videoRef.current.playbackRate = next;
  };

  const skip = (delta: number) => {
    const v = videoRef.current;
    if (!v) return;
    const d = v.duration || duration;
    const t = Math.min(Math.max(0, v.currentTime + delta), d);
    v.currentTime = t;
    setCurrentTime(t);
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  // Keyboard shortcut to close or toggle play
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;
      if (e.key === 'Escape') {
        handleClose();
      } else if (e.key === ' ') {
        e.preventDefault();
        togglePlay();
      } else if (e.key === 'ArrowLeft') {
        skip(-5);
      } else if (e.key === 'ArrowRight') {
        skip(5);
      } else if (e.key === 'm' || e.key === 'M') {
        toggleMute();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen]);

  // The whole "Watch the intro" row opens the video (it fires this event), not only the badge
  const openRef = useRef(handleBadgeClick);
  openRef.current = handleBadgeClick;
  useEffect(() => {
    if (!small && !headless) return;
    const open = () => openRef.current();
    window.addEventListener('dy:open-video', open);
    return () => window.removeEventListener('dy:open-video', open);
  }, [small, headless]);

  const pct = duration > 0 ? Math.min(100, (currentTime / duration) * 100) : 0;

  return (
    <>
      {/* =========================================================================
          1. Play badge (trigger only: modal + playback logic below are unchanged)
          ========================================================================= */}
      {headless ? null : compact ? (
        /* PC navbar version: premium round icon button (same glass + light-ring look as the cards) */
        <button
          type="button"
          onClick={handleBadgeClick}
          aria-label={isPlaying ? 'Pause video' : 'Play video'}
          title="Click to watch video"
          className={`pc-navbtn pc-logobtn pc-play ${isPlaying ? "is-active" : ""} outline-none focus-visible:ring-2 focus-visible:ring-white/70`}
        >
          <span className="pc-ico pc-ico-play">{isPlaying ? (
            <svg viewBox="0 0 24 24" className="w-[11px] h-[11px]" aria-hidden="true">
              <rect x="6" y="5" width="4.2" height="14" rx="1.4" fill="currentColor" />
              <rect x="13.8" y="5" width="4.2" height="14" rx="1.4" fill="currentColor" />
            </svg>
          ) : (
            <svg viewBox="0 0 24 24" className="w-[12px] h-[12px] translate-x-[0.5px]" aria-hidden="true">
              <path fill="currentColor" d="M8 5.6v12.8a1 1 0 0 0 1.52.86l10.3-6.4a1 1 0 0 0 0-1.72L9.52 4.74A1 1 0 0 0 8 5.6z" />
            </svg>
          )}</span>
          <span className="pc-lbl">{isPlaying ? "Pause" : "Watch video"}</span>
        </button>
      ) : (
      <div className={`relative select-none pointer-events-auto group ${small ? 'w-[76px] h-[76px]' : 'w-32 h-32 xs:w-36 xs:h-36 sm:w-36 sm:h-36 md:w-44 md:h-44'}`}>
        {/* Soft ripple rings (transform + opacity only) */}
        <span aria-hidden="true" className="badge-ripple absolute inset-0 rounded-full border-2 border-[#9DB8FF]/60 pointer-events-none" />
        <span aria-hidden="true" className="badge-ripple absolute inset-0 rounded-full border-2 border-[#9DB8FF]/40 pointer-events-none" style={{ animationDelay: '1.2s' }} />

        <button
          type="button"
          onClick={handleBadgeClick}
          aria-label="Play video"
          title="Click once to Open & Play Video!"
          className="relative w-full h-full rounded-full p-0 cursor-pointer outline-none border-0 transition-transform duration-300 group-hover:scale-105 active:scale-95 focus-visible:ring-4 focus-visible:ring-white/70 bg-[radial-gradient(120%_70%_at_50%_0%,rgba(111,155,255,0.30)_0%,rgba(111,155,255,0)_62%),linear-gradient(180deg,#10204e_0%,#070d26_58%,#04081a_100%)] shadow-[0_16px_34px_rgba(0,0,0,0.6),0_0_34px_rgba(80,120,255,0.38),inset_0_1px_2px_rgba(255,255,255,0.22)]"
        >
          {/* Rotating light border (same effect as the site cards) */}
          <span aria-hidden="true" className="border-wrapper" style={{ borderRadius: '50%', padding: '2.5px' }}>
            <span className="card-border-animation" />
          </span>
          {/* Rotating text ring (text spread evenly around the full circle) */}
          <div className={`badge-spin absolute inset-[5%] ${
            isPlaying ? 'animate-[spin_7s_linear_infinite]' : 'animate-[spin_12s_linear_infinite]'
          }`}>
            <svg viewBox="0 0 100 100" className="w-full h-full overflow-visible" aria-hidden="true">
              <path id="badgePath" d="M 50, 50 m -38, 0 a 38,38 0 1,1 76,0 a 38,38 0 1,1 -76,0" fill="none" />
              <text style={{ fontSize: '7.4px', fontWeight: 800, fill: '#C4D5FF', letterSpacing: '0.4px', textTransform: 'uppercase' }}>
                <textPath href="#badgePath" startOffset="0%" textLength="236" lengthAdjust="spacing">
                  • DEV YASIN • FAVOURITE MUSIC • PLAY VIDEO •
                </textPath>
              </text>
            </svg>
          </div>

          {/* Thin inner ring for depth */}
          <span aria-hidden="true" className="absolute inset-[24%] rounded-full border border-[#9DB8FF]/25 pointer-events-none" />

          {/* Center: dark glossy play button with neon icon */}
          <span className="absolute inset-[30%] rounded-full bg-gradient-to-br from-[#3a63d6] to-[#1a2f78] flex items-center justify-center shadow-[0_6px_16px_rgba(10,25,90,0.65),0_0_18px_rgba(80,120,255,0.55),0_0_0_1.5px_rgba(176,200,255,0.55),inset_0_1px_1px_rgba(255,255,255,0.4)] transition-transform duration-300 group-hover:scale-110">
            {isPlaying ? (
              <span className="flex flex-col items-center justify-center gap-[6%] w-full h-full">
                <Pause fill="#fff" className="w-[38%] h-[38%] text-white" />
                <span className="flex items-end gap-[3px] h-[16%]">
                  <span className="w-[3px] h-full bg-white rounded-full animate-[pulse_0.4s_ease-in-out_infinite]" />
                  <span className="w-[3px] h-1/2 bg-white rounded-full animate-[pulse_0.6s_ease-in-out_infinite]" />
                  <span className="w-[3px] h-[85%] bg-white rounded-full animate-[pulse_0.3s_ease-in-out_infinite]" />
                  <span className="w-[3px] h-1/2 bg-white rounded-full animate-[pulse_0.5s_ease-in-out_infinite]" />
                </span>
              </span>
            ) : (
              <Play fill="#fff" className="w-[46%] h-[46%] text-white ml-[6%]" />
            )}
          </span>

          {/* Glossy highlight */}
          <span aria-hidden="true" className="absolute top-[7%] left-[18%] w-[42%] h-[20%] rounded-[50%] bg-gradient-to-b from-white/20 to-transparent -rotate-[20deg] pointer-events-none" />
        </button>
      </div>
      )}

      {/* =========================================================================
          2. Ultra-Sleek Glassmorphic Video Player Modal
          ========================================================================= */}
      {createPortal(
      <AnimatePresence>
        {isOpen && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-3 sm:p-5 pointer-events-auto bg-black/20 backdrop-blur-[4.8px] animate-in fade-in duration-300 overscroll-none">
            
            {/* Backdrop click to close */}
            <div 
              className="absolute inset-0"
              onClick={handleClose}
            />

            {/* Main Player Card with 3% Glassmorphism matching site */}
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 25 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 25 }}
              transition={{ type: "spring", stiffness: 350, damping: 28 }}
              className="relative z-10 w-[92vw] max-w-[360px] sm:max-w-[500px] lg:max-w-[560px] bg-white/[0.06] backdrop-blur-2xl border border-white/25 rounded-[2rem] sm:rounded-[2.4rem] p-4 sm:p-7 shadow-[0_30px_90px_rgba(0,0,0,0.6),0_0_50px_rgba(255,255,255,0.08),inset_0_1.5px_2px_rgba(255,255,255,0.3)] select-none text-white overflow-hidden"
            >
              
              {/* Header Bar with Official Circular Logo */}
              <div className="flex items-center justify-between pb-3 border-b border-white/[0.14]">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-full overflow-hidden border-[1.5px] border-[#9DB8FF] shadow-[0_0_12px_rgba(111,155,255,0.55)] flex-shrink-0">
                    <img src="/avatar-120.jpg" srcSet="/avatar-80.jpg 80w, /avatar-120.jpg 120w, /avatar-160.jpg 160w" sizes="36px" decoding="async" alt="Dev Yasin Logo" className="w-full h-full object-cover" />
                  </div>
                  <div className="text-left leading-tight">
                    <h3 className="m-0 text-[0.82rem] font-black text-white tracking-[0.14em] uppercase flex items-center gap-1.5">
                      <span>Dev Yasin</span>
                      <svg viewBox="0 0 24 24" className="w-3.5 h-3.5 fill-[#00F2FE] flex-shrink-0" aria-hidden="true">
                        <path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10 10-4.5 10-10S17.5 2 12 2zm-1.2 14.2l-3.5-3.5 1.4-1.4 2.1 2.1 5.3-5.3 1.4 1.4-6.7 6.7z" />
                      </svg>
                    </h3>
                    <p className="m-0 mt-0.5 text-[10px] text-[#9DB8FF] font-semibold tracking-[0.16em] uppercase">
                      Official Video
                    </p>
                  </div>
                </div>

                <button
                  onClick={handleClose}
                  className="w-8 h-8 rounded-full bg-white/[0.08] hover:bg-white/[0.18] text-white flex items-center justify-center transition-all cursor-pointer border border-white/20 active:scale-90"
                  title="Close (Esc)"
                  aria-label="Close player"
                >
                  <X size={16} />
                </button>
              </div>

              {/* Media viewport */}
              <div className="my-3 sm:my-4 relative flex justify-center">
                <div className="w-full max-w-[280px] xs:max-w-[320px] sm:max-w-[400px] lg:max-w-[440px] aspect-square vp-video-layer rounded-[1.6rem] sm:rounded-[2rem] overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.45),0_0_0_1px_rgba(157,184,255,0.25)] bg-black/40 relative flex items-center justify-center group">
                  <video
                    ref={videoRef}
                    src={videoSrc}
                    preload="auto"
                    controls={false}
                    controlsList="nodownload nofullscreen noremoteplayback"
                    disablePictureInPicture
                    disableRemotePlayback
                    draggable={false}
                    onContextMenu={(e) => e.preventDefault()}
                    poster="/devyasinx.jpg"
                    loop={isLooping}
                    playsInline
                    onTimeUpdate={handleTimeUpdate}
                    onLoadedMetadata={handleLoadedMetadata}
                    onPlay={() => setIsPlaying(true)}
                    onPause={() => setIsPlaying(false)}
                    onClick={togglePlay}
                    className="w-full h-full object-cover cursor-pointer vp-no-save"
                  />

                  {/* Soft vignette at the bottom of the picture (static) */}
                  <div className="absolute inset-x-0 bottom-0 h-1/4 bg-gradient-to-t from-black/45 to-transparent pointer-events-none" />

                  {/* Centered play button while paused */}
                  {!isPlaying && (
                    <div
                      onClick={togglePlay}
                      className="absolute inset-0 bg-black/30 flex items-center justify-center cursor-pointer"
                    >
                      <div className="w-16 h-16 rounded-full flex items-center justify-center text-white border border-white/50 bg-gradient-to-br from-[#3a63d6] to-[#1a2f78] shadow-[0_0_28px_rgba(80,120,255,0.65),inset_0_1px_1px_rgba(255,255,255,0.4)] active:scale-95 transition-transform">
                        <Play size={26} fill="white" className="translate-x-[2px]" />
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Timeline */}
              <div className="mb-3 px-1">
                <input
                  type="range"
                  min="0"
                  max={duration || 10}
                  step="0.05"
                  value={currentTime}
                  onChange={handleSeek}
                  aria-label="Seek"
                  className="vp-range w-full cursor-pointer"
                  style={{ background: `linear-gradient(90deg, #6F9BFF 0%, #C4D5FF ${pct}%, rgba(255,255,255,0.16) ${pct}%)` }}
                />
                <div className="mt-1.5 flex justify-between text-[11px] font-mono font-bold tabular-nums">
                  <span className="text-[#C4D5FF]">{formatTime(currentTime)}</span>
                  <span className="text-white/50">{formatTime(duration)}</span>
                </div>
              </div>

              {/* Controls: volume | skip - play - skip | speed + loop (centre column is truly centred) */}
              <div className="vp-controls grid grid-cols-[1fr_auto_1fr] items-center gap-1 px-2.5 sm:px-4 py-2.5 sm:py-3">
                {/* Left: volume */}
                <div className="flex items-center gap-1.5 justify-self-start">
                  <button
                    onClick={toggleMute}
                    className="p-1 text-white/80 hover:text-white transition-colors cursor-pointer"
                    title={isMuted ? 'Unmute (M)' : 'Mute (M)'}
                    aria-label={isMuted ? 'Unmute' : 'Mute'}
                  >
                    {isMuted || volume === 0 ? <VolumeX size={18} /> : <Volume2 size={18} />}
                  </button>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={isMuted ? 0 : volume}
                    onChange={handleVolumeChange}
                    aria-label="Volume"
                    className="vp-range vp-range-sm w-14 sm:w-24 cursor-pointer"
                    style={{ background: `linear-gradient(90deg, #9DB8FF ${(isMuted ? 0 : volume) * 100}%, rgba(255,255,255,0.2) ${(isMuted ? 0 : volume) * 100}%)` }}
                  />
                  <span className="hidden sm:block w-8 text-[10px] font-mono font-bold tabular-nums text-white/50">
                    {Math.round((isMuted ? 0 : volume) * 100)}%
                  </span>
                </div>

                {/* Centre: -5s | play | +5s */}
                <div className="flex items-center gap-3 sm:gap-4 justify-self-center">
                  <button
                    onClick={() => skip(-5)}
                    className="relative w-8 h-8 rounded-full text-white/75 hover:text-white flex items-center justify-center cursor-pointer active:scale-90 transition-all"
                    title="Back 5 seconds (←)"
                    aria-label="Back 5 seconds"
                  >
                    <RotateCcw size={20} />
                    <span className="absolute text-[7px] font-black leading-none mt-px">5</span>
                  </button>
                  <button
                    onClick={togglePlay}
                    className={`vp-playbtn w-12 h-12 sm:w-14 sm:h-14 rounded-full text-white flex items-center justify-center cursor-pointer active:scale-95 transition-transform ${isPlaying ? 'is-playing' : ''}`}
                    title={isPlaying ? 'Pause (Space)' : 'Play (Space)'}
                    aria-label={isPlaying ? 'Pause' : 'Play'}
                  >
                    {isPlaying ? <Pause size={20} fill="white" /> : <Play size={20} fill="white" className="translate-x-[1.5px]" />}
                  </button>
                  <button
                    onClick={() => skip(5)}
                    className="relative w-8 h-8 rounded-full text-white/75 hover:text-white flex items-center justify-center cursor-pointer active:scale-90 transition-all"
                    title="Forward 5 seconds (→)"
                    aria-label="Forward 5 seconds"
                  >
                    <RotateCw size={20} />
                    <span className="absolute text-[7px] font-black leading-none mt-px">5</span>
                  </button>
                </div>

                {/* Right: speed + loop */}
                <div className="flex items-center gap-1.5 justify-self-end">
                  <button
                    onClick={cycleSpeed}
                    className="min-w-[38px] h-6 px-1.5 rounded-full text-[10.5px] font-black tabular-nums text-[#C4D5FF] bg-white/[0.07] border border-white/20 cursor-pointer active:scale-90 transition-transform"
                    title="Playback speed"
                    aria-label="Playback speed"
                  >
                    {speed}x
                  </button>
                  <button
                    onClick={() => setIsLooping(!isLooping)}
                    className={`w-7 h-7 rounded-full flex items-center justify-center transition-all cursor-pointer active:scale-90 ${
                      isLooping ? 'text-white bg-[#6F9BFF]/30 border border-[#9DB8FF]/60' : 'text-white/55 hover:text-white border border-transparent'
                    }`}
                    title={isLooping ? 'Loop on' : 'Loop off'}
                    aria-label="Loop"
                    aria-pressed={isLooping}
                  >
                    <Repeat size={14} />
                  </button>
                </div>
              </div>

              {/* Keyboard hints (PC only) */}
              <div className="hidden sm:flex items-center justify-center gap-3 mt-3 text-[10px] font-semibold text-white/40">
                <span><kbd className="vp-kbd">Space</kbd> Play</span>
                <span><kbd className="vp-kbd">←</kbd><kbd className="vp-kbd">→</kbd> 5s</span>
                <span><kbd className="vp-kbd">M</kbd> Mute</span>
                <span><kbd className="vp-kbd">Esc</kbd> Close</span>
              </div>

              {/* Skills / Profile Badges Footer */}
              <div className="mt-3 sm:mt-4 pt-3 border-t border-white/10 flex items-center justify-center gap-1.5 flex-wrap">
                {['Website Dev', 'Software Dev', 'Windows Dev', 'Discord Bot'].map((t) => (
                  <span key={t} className="px-2.5 py-0.5 rounded-full bg-white/[0.05] border border-[#9DB8FF]/30 text-[10px] font-bold text-[#DCE6FF]">
                    {t}
                  </span>
                ))}
              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>,
      document.body
      )}
    </>
  );
};
