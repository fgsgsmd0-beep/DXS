import HoldDrag from "./hold-drag";
import React, { useState, useSyncExternalStore } from 'react';
import { createPortal } from 'react-dom';
import { LazyMotion, m, AnimatePresence } from 'motion/react';
import { 
  Home, 
  Globe,
  Smartphone,
  Bot,
  Key,
  Star,
  ShieldCheck,
  Monitor,
  MoreVertical,
  ArrowUpRight,
  X
} from 'lucide-react';
import { DevYasinXPlayer } from './video-music-player';
import { HeroOdyssey } from './hero-odyssey';

// --- Custom Hand-Drawn SVG Accents ---

const ArrowGreenLeft = () => (
  <svg viewBox="0 0 100 100" className="w-full h-full text-[#9DB8FF] stroke-current overflow-visible" fill="none" strokeWidth="7" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12,85 C 10,45 35,25 65,52 C 75,62 85,72 95,70" />
    <path d="M80,55 L95,70 L83,85" />
  </svg>
);

const ArrowGreenRightPointingLeft = () => (
  <svg viewBox="0 0 100 100" className="w-full h-full text-[#9DB8FF] stroke-current overflow-visible" fill="none" strokeWidth="7" strokeLinecap="round" strokeLinejoin="round">
    <path d="M88,85 C 90,45 65,25 35,52 C 25,62 15,72 5,70" />
    <path d="M20,55 L5,70 L17,85" />
  </svg>
);

const ArrowGreenRight = () => (
  <svg viewBox="0 0 100 100" className="w-full h-full text-[#9DB8FF] stroke-current overflow-visible" fill="none" strokeWidth="6.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M85,15 C 80,55 65,75 45,60 C 30,45 42,28 60,34 C 75,40 72,65 52,78 L 46,84" />
    <path d="M60,78 L 46,84 L 52,70" />
  </svg>
);


// --- Official Verified Badge Icon ---

const VerifiedBadge = () => (
  <span title="Verified Creator" className="inline-flex items-center">
    <svg viewBox="0 0 24 24" className="w-4 h-4 sm:w-5 sm:h-5 fill-[#00F2FE] flex-shrink-0 drop-shadow-[0_0_8px_rgba(0,242,254,0.9)]">
      <path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10 10-4.5 10-10S17.5 2 12 2zm-1.2 14.2l-3.5-3.5 1.4-1.4 2.1 2.1 5.3-5.3 1.4 1.4-6.7 6.7z" />
    </svg>
  </span>
);

// --- Official Social Media Vector Logos ---

const YouTubeLogo = ({ mobile = false }) => (
  <div className={`${mobile ? 'w-14 h-14' : 'w-14 h-14 sm:w-22 sm:h-22 md:w-26 md:h-26 lg:w-28 lg:h-28'} bg-[#FF0000] rounded-full flex items-center justify-center ${mobile ? 'mb-2' : 'mb-2 sm:mb-3.5'} shadow-[0_8px_25px_rgba(255,0,0,0.55)] border-[2px] sm:border-[2.5px] border-white/95 overflow-hidden flex-shrink-0 transition-transform group-hover:scale-110`}>
    <svg viewBox="0 0 24 24" className={`${mobile ? 'w-7 h-7' : 'w-7 h-7 sm:w-11 sm:h-11 md:w-13 md:h-13 lg:w-14 lg:h-14'} fill-white drop-shadow-sm`}>
      <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
    </svg>
  </div>
);

const TikTokLogo = ({ mobile = false }) => (
  <div className={`${mobile ? 'w-14 h-14' : 'w-14 h-14 sm:w-22 sm:h-22 md:w-26 md:h-26 lg:w-28 lg:h-28'} bg-[#010101] rounded-full flex items-center justify-center ${mobile ? 'mb-2' : 'mb-2 sm:mb-3.5'} shadow-[0_8px_25px_rgba(0,0,0,0.65),0_0_15px_rgba(111,155,255,0.4)] border-[2px] sm:border-[2.5px] border-white/95 overflow-hidden flex-shrink-0 transition-transform group-hover:scale-110`}>
    <svg viewBox="0 0 24 24" className={`${mobile ? 'w-7 h-7' : 'w-7 h-7 sm:w-11 sm:h-11 md:w-12 md:h-12 lg:w-13 lg:h-13'} fill-white drop-shadow-[0_0_6px_rgba(157,184,255,0.5)]`}>
      <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 3 15.68 6.34 6.34 0 0 0 9.34 22a6.33 6.33 0 0 0 6.33-6.33V9.2a8.16 8.16 0 0 0 4.92 1.63V7.39a4.85 4.85 0 0 1-1-.7z"/>
    </svg>
  </div>
);

// helper: allows CSS custom properties in style objects
const sv = (o: Record<string, string | number>) => o as unknown as React.CSSProperties;

const loadMotionFeatures = () => import('./motion-features').then((r) => r.default);

// --- Render only ONE layout (the old code mounted mobile + desktop at the same time) ---
const DESKTOP_QUERY = '(min-width: 640px)';
// PC: wide screens get the "Hero Odyssey" home design; phones/tablets keep the original hero
const PC_QUERY = '(min-width: 1024px)';
function useMediaQuery(query: string) {
  return useSyncExternalStore(
    (cb) => {
      const mq = window.matchMedia(query);
      mq.addEventListener('change', cb);
      return () => mq.removeEventListener('change', cb);
    },
    () => window.matchMedia(query).matches,
    () => false
  );
}
const useIsDesktop = () => useMediaQuery(DESKTOP_QUERY);
const useIsPC = () => useMediaQuery(PC_QUERY);

// --- Navbar config ---
const navItems = [
  { name: 'Home', icon: Home },
  { name: 'Free Web', icon: Globe },
  { name: 'APK', icon: Smartphone },
  { name: 'BOT', icon: Bot },
  { name: 'API', icon: Key },
  { name: 'Review', icon: Star },
  { name: 'PC Tools', icon: Monitor },
];

// Phone menu lists every section of the page, in page order (desktop navbar keeps navItems above)
const mobileNavItems = [
  { name: 'Home', label: 'Home', icon: Home },
  { name: 'Free Web', label: 'Free Website', icon: Globe },
  { name: 'APK', label: 'APK Building', icon: Smartphone },
  { name: 'BOT', label: 'Bot Making', icon: Bot },
  { name: 'Security', label: 'Security', icon: ShieldCheck },
  { name: 'API', label: 'API Key', icon: Key },
  { name: 'Review', label: 'Review Project', icon: Star },
  { name: 'PC Tools', label: 'PC Tools', icon: Monitor },
];

// Phone: scroll straight to each card (below the fixed top bar), not to the top of the whole section
const MOBILE_SCROLL_TARGETS: Record<string, string> = {
  'Free Web': 'card-free-website',
  APK: 'card-apk',
  BOT: 'card-bot',
  Security: 'card-security',
  API: 'card-api',
  Review: 'card-review',
  'PC Tools': 'card-pctools',
};

const NAV_TARGETS: Record<string, { event: string; target: string }> = {
  'Free Web': { event: 'select-free-web', target: 'resource-section' },
  APK: { event: 'select-apk-building', target: 'resource-section' },
  BOT: { event: 'select-bot-card', target: 'resource-section' },
  API: { event: 'select-api-card', target: 'card-api' },
  Review: { event: 'select-review-card', target: 'card-review' },
  Security: { event: 'select-security-card', target: 'card-security' },
  'PC Tools': { event: 'select-pctools-card', target: 'card-pctools' },
};

// --- Small shared pieces ---
const SocialText = ({ handle, hover, desktop = false }: { handle: string; hover: string; desktop?: boolean }) => (
  <div className={`text-center ${desktop ? 'mt-1' : 'mt-1 relative z-10'}`}>
    <p className={desktop
      ? 'font-extrabold text-lg md:text-xl lg:text-[1.35rem] tracking-tight font-sans flex items-center justify-center gap-2 glow-text-white'
      : 'font-extrabold text-[14.5px] xs:text-[15.5px] tracking-tight font-sans flex items-center justify-center gap-1.5 glow-text-white'}>
      <span>Dev Yasin</span>
      <VerifiedBadge />
    </p>
    <p className={desktop
      ? `text-sm md:text-base text-white/90 font-bold mt-1 font-sans flex items-center justify-center gap-1 ${hover} transition-colors drop-shadow-sm`
      : `text-[10.5px] xs:text-[11px] text-white/90 font-bold mt-0.5 font-sans ${hover} transition-colors drop-shadow-sm`}>
      {handle}
    </p>
  </div>
);

const TitleStack = ({ desktop }: { desktop: boolean }) => {
  const line1 = desktop
    ? 'text-[6.2rem] md:text-[8rem] lg:text-[9.8rem] xl:text-[11.2rem] font-black leading-[0.84]'
    : 'text-[16.5vw] xs:text-[17.5vw] font-black leading-[0.85]';
  const line2 = desktop
    ? 'text-[5.5rem] md:text-[7.2rem] lg:text-[8.8rem] xl:text-[10.2rem] font-black leading-[0.84]'
    : 'text-[14.2vw] xs:text-[15.2vw] font-black leading-[0.85]';
  return (
    <div
      className={`hero-in w-full flex flex-col items-center select-none relative z-10 ${
        desktop ? 'space-y-2 md:space-y-3' : 'space-y-0 pt-0 mt-0.5'
      }`}
      style={{ animationDelay: '0.12s' }}
    >
      <div className={`w-full flex justify-center relative z-10 ${desktop ? '-translate-x-[7%] md:-translate-x-[9%]' : '-translate-x-[3%]'}`}>
        <h1 className={`${line1} text-[#9DB8FF] m-0 p-0 uppercase font-display text-3d-shadow tracking-tight`}>WELCOME</h1>
      </div>
      <div className="w-full flex justify-center relative z-20">
        <h1 className={`${line2} text-white m-0 p-0 uppercase tracking-tighter font-display text-3d-shadow`}>DEVELOPER</h1>
      </div>
      <div className={`w-full flex justify-center relative z-10 ${desktop ? 'translate-x-[7%] md:translate-x-[9%]' : 'translate-x-[3%]'}`}>
        <h1 className={`${line1} text-white m-0 p-0 uppercase font-display text-3d-shadow tracking-tight`}>WEBSITE</h1>
      </div>
    </div>
  );
};

// --- Phone: smooth, interruptible eased scroll (runs on requestAnimationFrame) ---
let scrollRaf = 0;
function smoothScrollToY(targetY: number, onDone?: () => void) {
  cancelAnimationFrame(scrollRaf);
  const maxY = document.documentElement.scrollHeight - window.innerHeight;
  const to = Math.max(0, Math.min(targetY, maxY));
  const from = window.scrollY;
  const dist = to - from;
  if (Math.abs(dist) < 2 || window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    window.scrollTo({ top: to, behavior: 'instant' as ScrollBehavior });
    onDone?.();
    return;
  }
  const duration = Math.min(900, Math.max(380, Math.abs(dist) * 0.35));
  const start = performance.now();
  const cancel = () => {
    cancelAnimationFrame(scrollRaf);
    cleanup();
  };
  const cleanup = () => {
    window.removeEventListener('touchstart', cancel);
    window.removeEventListener('wheel', cancel);
  };
  window.addEventListener('touchstart', cancel, { passive: true });
  window.addEventListener('wheel', cancel, { passive: true });
  const ease = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
  const step = (now: number) => {
    const t = Math.min(1, (now - start) / duration);
    window.scrollTo({ top: from + dist * ease(t), behavior: 'instant' as ScrollBehavior });
    if (t < 1) {
      scrollRaf = requestAnimationFrame(step);
    } else {
      cleanup();
      onDone?.();
    }
  };
  scrollRaf = requestAnimationFrame(step);
}

// --- Phone side menu: owns its own state so opening it never re-renders the whole hero ---
const MobileMenu = React.memo(function MobileMenu({
  activeTab,
  onSelect,
}: {
  activeTab: string;
  onSelect: (name: string) => void;
}) {
  const [open, setOpen] = useState(false);
  // Heavy blur is switched on only once the slide-in has finished (keeps the animation smooth)
  const [settled, setSettled] = useState(false);

  const close = () => setOpen(false);
  const choose = (name: string) => {
    setOpen(false);
    onSelect(name);
  };

  // Lock page scroll behind the menu; Esc closes it
  React.useEffect(() => {
    if (!open) {
      setSettled(false);
      return;
    }
    const html = document.documentElement;
    const prev = html.style.overflow;
    html.style.overflow = 'hidden';
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false);
    window.addEventListener('keydown', onKey);
    return () => {
      html.style.overflow = prev;
      html.classList.remove('menu-open');
      window.removeEventListener('keydown', onKey);
    };
  }, [open]);

  // Page animations behind the menu pause once the menu has settled (they resume on close)
  React.useEffect(() => {
    if (!open || !settled) return;
    const id = requestAnimationFrame(() => document.documentElement.classList.add('menu-open'));
    return () => cancelAnimationFrame(id);
  }, [open, settled]);

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="w-8 h-8 rounded-full bg-white/[0.12] border border-white/20 flex items-center justify-center text-white active:scale-90 transition-transform cursor-pointer ml-auto"
        aria-label="Open menu"
        aria-expanded={open}
        aria-haspopup="dialog"
      >
        <MoreVertical size={17} />
      </button>
      {createPortal(
        <>
            {/* Glass side drawer (slides in from the right) */}
            <AnimatePresence>
              {open && (
                <>
                  <m.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className={`fixed inset-0 z-[105] bg-black/25 ${settled ? 'backdrop-blur-[4.8px]' : ''}`}
                    onClick={() => close()}
                  />
                  <m.aside
                    role="dialog"
                    aria-label="Menu"
                    initial={{ transform: 'translate3d(100%,0,0)' }}
                    animate={{ transform: 'translate3d(0%,0,0)' }}
                    exit={{ transform: 'translate3d(100%,0,0)' }}
                    transition={{ duration: 0.28, ease: [0.22, 1, 0.36, 1] }}
                    onAnimationComplete={(def) => {
                      if (open && (def as unknown as { transform?: string }).transform === 'translate3d(0%,0,0)') setSettled(true);
                    }}
                    className={`fixed top-0 right-0 bottom-0 z-[110] w-[58vw] min-w-[215px] max-w-[250px] flex flex-col ${settled ? 'backdrop-blur-xl' : ''} bg-white/[0.1] border-l-[0.75px] border-y-[0.75px] border-white/[0.32] rounded-l-[1.6rem] shadow-[-16px_0_40px_rgba(0,0,0,0.38),-4px_0_22px_rgba(111,155,255,0.22),inset_0.75px_0.75px_1px_rgba(255,255,255,0.35),inset_0_-1px_1px_rgba(255,255,255,0.12)] text-white overflow-hidden`}
                    style={{ willChange: 'transform', backgroundImage: 'linear-gradient(160deg, rgba(255,255,255,0.12) 0%, rgba(255,255,255,0) 42%), linear-gradient(180deg, rgba(8,16,48,0.30) 0%, rgba(4,8,24,0.42) 100%)', paddingTop: 'env(safe-area-inset-top, 0px)', paddingBottom: 'env(safe-area-inset-bottom, 0px)' }}
                  >
                    {/* Header: profile + close */}
                    <div className="flex items-center gap-2 px-3 pt-4 pb-3 border-b border-white/[0.14]">
                      <div className="w-9 h-9 rounded-full overflow-hidden border-[1.5px] border-white/90 shadow-[0_0_8px_rgba(111,155,255,0.45)] flex-shrink-0">
                        <img src="/avatar-120.jpg" srcSet="/avatar-80.jpg 80w, /avatar-120.jpg 120w, /avatar-160.jpg 160w" sizes="36px" alt="Dev Yasin" width={36} height={36} decoding="async" className="w-full h-full object-cover" />
                      </div>
                      <div className="flex flex-col min-w-0">
                        <div className="flex items-center gap-1">
                          <span className="font-black text-[0.92rem] tracking-tight font-sans whitespace-nowrap">Dev Yasin</span>
                          <VerifiedBadge />
                        </div>
                        <span className="font-bold text-[0.48rem] tracking-[1.4px] uppercase text-[#9DB8FF] whitespace-nowrap">Official Website</span>
                      </div>
                      <button
                        onClick={() => close()}
                        className="ml-auto w-7 h-7 rounded-full bg-white/[0.12] border border-white/25 flex items-center justify-center active:scale-90 transition-transform cursor-pointer flex-shrink-0"
                        aria-label="Close menu"
                      >
                        <X size={14} />
                      </button>
                    </div>

                    {/* Menu items */}
                    <nav className="flex-1 overflow-y-auto px-2.5 py-2.5 flex flex-col gap-1">
                      {mobileNavItems.map((item, index) => {
                        const Icon = item.icon;
                        const isActive = activeTab === item.name;
                        return (
                          <m.button
                            key={item.name}
                            initial={{ opacity: 0, x: 24 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: 0.06 + index * 0.04 }}
                            onClick={() => choose(item.name)}
                            className={`flex items-center gap-2.5 px-3 py-2 rounded-xl text-[0.8rem] font-bold cursor-pointer text-left ${
                              isActive
                                ? 'bg-white/[0.16] text-white border border-white/35'
                                : 'text-white/80 border border-transparent active:bg-white/[0.1]'
                            }`}
                          >
                            <Icon size={16} className={isActive ? 'text-[#9DB8FF]' : 'text-white/60'} />
                            <span>{item.label}</span>
                            {isActive && <span className="w-1.5 h-1.5 rounded-full bg-[#6F9BFF] shadow-[0_0_8px_#6F9BFF] ml-auto" />}
                          </m.button>
                        );
                      })}
                    </nav>

                    <div className="px-3 py-2.5 border-t border-white/15 text-center text-[8px] leading-tight font-bold tracking-wider uppercase text-white/50">
                      Creative Developer • Video Creator
                    </div>
                  </m.aside>
                </>
              )}
            </AnimatePresence>

        </>,
        document.body
      )}
    </>
  );
});

export const Component = () => {
  const [activeTab, setActiveTab] = useState('Home');
  const isDesktop = useIsDesktop();
  const isPC = useIsPC();
  const heroRef = React.useRef<HTMLElement>(null);

  // Phones / tablets: once the hero has scrolled out of view, its looping animations rest
  // (html.hero-off, see index.css). They start again just before the hero comes back on screen,
  // so nothing is ever visibly missing - the browser just stops animating things nobody can see.
  React.useEffect(() => {
    const el = heroRef.current;
    if (isPC || !el || typeof IntersectionObserver === 'undefined') return;
    const html = document.documentElement;
    const io = new IntersectionObserver(
      ([entry]) => html.classList.toggle('hero-off', !entry.isIntersecting),
      { rootMargin: '160px 0px' }
    );
    io.observe(el);
    return () => {
      io.disconnect();
      html.classList.remove('hero-off');
    };
  }, [isPC]);

  const handleNavItemClick = React.useCallback((itemName: string) => {
    const cfg = NAV_TARGETS[itemName];

    // Desktop: unchanged behaviour
    if (isDesktop) {
      setActiveTab(itemName);
      if (itemName === 'Home') {
        window.scrollTo({ top: 0, behavior: 'smooth' });
        return;
      }
      if (!cfg) return;
      window.dispatchEvent(new CustomEvent(cfg.event));
      document.getElementById(cfg.target)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      return;
    }

    // Phone: one single eased scroll (no competing scrolls), highlight plays when it arrives
    setTimeout(() => {
      setActiveTab(itemName);
      if (itemName === 'Home') {
        smoothScrollToY(0);
        return;
      }
      const el = document.getElementById(MOBILE_SCROLL_TARGETS[itemName] ?? cfg?.target ?? '');
      if (!el) return;
      const margin = parseFloat(getComputedStyle(el).scrollMarginTop) || 0;
      smoothScrollToY(el.getBoundingClientRect().top + window.scrollY - margin, () => {
        if (cfg) window.dispatchEvent(new CustomEvent(cfg.event, { detail: { skipScroll: true } }));
      });
    }, 160);
  }, [isDesktop]);

  // PC: new Hero Odyssey home design (the sections below the hero stay exactly the same)
  if (isPC) {
    return (
      <LazyMotion features={loadMotionFeatures}>
        <HeroOdyssey activeTab={activeTab} onNavigate={handleNavItemClick} />
      </LazyMotion>
    );
  }

  return (
    <LazyMotion features={loadMotionFeatures}>
      <div className="min-h-screen min-h-[100dvh] w-full bg-transparent text-white flex flex-col font-sans relative overflow-x-hidden">


        {!isDesktop && (
          <>

            {/* ===== MOBILE NAVBAR (solid colour: no backdrop blur over a scrolling page) ===== */}
            <nav className="nav-in fixed top-0 left-0 right-0 z-[100] w-full px-3.5 py-1.5 flex items-center justify-between m-topbar">
              <a href="#" className="flex items-center gap-2.5 no-underline group select-none">
                <div className="relative w-[35px] h-[35px] xs:w-[38px] xs:h-[38px] rounded-full overflow-hidden border-[1.5px] border-white/90 shadow-[0_0_8px_rgba(111,155,255,0.45)] flex-shrink-0 active:scale-95">
                  <img
                    src="/avatar-120.jpg"
                    srcSet="/avatar-80.jpg 80w, /avatar-120.jpg 120w, /avatar-160.jpg 160w"
                    sizes="38px"
                    alt="Logo Profile"
                    width={38}
                    height={38}
                    decoding="async"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex flex-col justify-center gap-0 line-clamp-1">
                  <div className="flex items-center gap-1">
                    <span className="font-black text-[0.98rem] xs:text-[1.05rem] text-white tracking-tight font-sans whitespace-nowrap drop-shadow-sm">
                      Dev Yasin
                    </span>
                    <VerifiedBadge />
                  </div>
                  <span className="font-bold text-[0.52rem] xs:text-[0.56rem] tracking-[2.2px] uppercase text-[#9DB8FF] whitespace-nowrap">
                    Official Website
                  </span>
                </div>
              </a>

              <MobileMenu activeTab={activeTab} onSelect={handleNavItemClick} />
            </nav>

          </>
        )}

        {/* ===== DESKTOP NAVBAR ===== */}
        {isDesktop && (
          <header className="nav-in relative z-50 w-full pt-4 sm:pt-5 px-3 flex items-center justify-center pointer-events-auto">
            <nav className="relative overflow-hidden flex items-center gap-0.5 sm:gap-1 bg-white/[0.08] border border-white/20 p-1 sm:p-1.5 rounded-full shadow-[0_12px_30px_rgba(0,0,0,0.3),inset_0_1px_1.5px_rgba(255,255,255,0.25)]">
              <div className="nav-shimmer absolute inset-y-0 w-20 bg-gradient-to-r from-transparent via-white/20 to-transparent pointer-events-none" />
              {navItems.map((item, index) => {
                const Icon = item.icon;
                const isActive = activeTab === item.name;
                return (
                  <button
                    key={item.name}
                    onClick={() => handleNavItemClick(item.name)}
                    style={sv({ animationDelay: (0.22 + index * 0.05) + 's', '--fy': '-20px', '--fs': 0.85 })}
                    className={`pop-in relative px-2.5 sm:px-3 md:px-3.5 py-1 sm:py-1.5 text-[11px] sm:text-xs font-semibold rounded-full transition-colors duration-300 cursor-pointer select-none flex items-center gap-1.5 group ${
                      isActive ? 'text-white' : 'text-white/70 hover:text-white hover:bg-white/[0.05]'
                    }`}
                  >
                    {isActive && (
                      <m.div
                        layoutId="activeNavPill"
                        className="absolute inset-0 bg-white/[0.12] rounded-full border border-white/25 shadow-[0_3px_15px_rgba(255,255,255,0.12),inset_0_1px_1.5px_rgba(255,255,255,0.35)]"
                        transition={{ type: 'spring', stiffness: 450, damping: 32 }}
                      />
                    )}
                    <span className="relative z-10 flex items-center gap-1 sm:gap-1.5">
                      <Icon size={12.5} className={`transition-transform duration-300 group-hover:scale-110 ${isActive ? 'text-[#9DB8FF]' : 'text-white/60 group-hover:text-white'}`} />
                      <span className="tracking-tight">{item.name}</span>
                      {isActive && <span className="w-1 h-1 rounded-full bg-[#6F9BFF] shadow-[0_0_6px_#6F9BFF] animate-pulse ml-0.5" />}
                    </span>
                  </button>
                );
              })}
            </nav>
          </header>
        )}

        {/* Hero Section */}
        <main ref={heroRef} className="m-hero flex-1 relative z-20 w-full max-w-[1360px] mx-auto px-3 sm:px-4 flex flex-col items-center justify-center py-0">
          <div className="relative w-full max-w-[1240px] mx-auto flex flex-col items-center justify-center">

            {/* ===== MOBILE LAYOUT (premium / editorial) ===== */}
            {!isDesktop && (
              <div className="flex flex-col w-full relative pt-[88px] pb-8 px-2 min-h-[100dvh] text-left">
                {/* soft spotlight behind the title (static, costs nothing) */}
                <div className="absolute -top-10 left-1/2 -translate-x-1/2 w-[130%] h-[340px] pointer-events-none" style={{ background: 'radial-gradient(closest-side, rgba(70,110,255,0.20) 0%, rgba(70,110,255,0.06) 55%, rgba(70,110,255,0) 100%)' }} />

                {/* ===== First screen: everything the visitor sees on arrival ===== */}
                <div className="relative flex flex-col min-h-[calc(100dvh-88px-24px)]">
                {/* Eyebrow */}
                <div className="hero-in relative flex items-center gap-2.5" style={{ animationDelay: '0.08s' }}>
                  <span className="w-1.5 h-1.5 rounded-full bg-[#6F9BFF] shadow-[0_0_8px_#6F9BFF] animate-pulse" />
                  <span className="text-[10.5px] font-semibold tracking-[0.22em] uppercase text-[#9DB8FF]">Welcome Developer Website</span>
                  <span className="flex-1 h-px bg-gradient-to-r from-[#6F9BFF]/50 to-transparent" />
                </div>

                {/* Title */}
                <div className="hero-in relative mt-4 select-none" style={{ animationDelay: '0.16s' }}>
                  <h1 className="m-0 flex items-center gap-2.5 text-[3.9rem] xs:text-[4.3rem] leading-[0.98] font-light tracking-[-0.045em] bg-gradient-to-b from-white via-white to-[#9DB8FF] bg-clip-text text-transparent">
                    Dev Yasin
                  </h1>
                  <p className="m-0 mt-2 text-[1.55rem] xs:text-[1.7rem] leading-tight italic bg-gradient-to-r from-[#C4D5FF] via-[#9DB8FF] to-[#6F9BFF] bg-clip-text text-transparent" style={{ fontFamily: "'Instrument Serif', Georgia, 'Times New Roman', serif" }}>
                    Creative Developer • Video Creator
                  </p>
                  <p className="m-0 mt-4 max-w-[20rem] text-[0.84rem] leading-[1.65] text-white/55">
                    Free websites, APK building, bots and API keys — all in one place.
                  </p>
                </div>

                {/* Telegram channel (main call to action) */}
                <div className="hero-in relative mt-6" style={{ animationDelay: '0.26s' }}>
                  <a
                    href="https://t.me/auraffxofficial"
                    target="_blank"
                    rel="noopener noreferrer"
                    title="Join the Telegram channel"
                    className="relative overflow-hidden w-full flex items-center gap-3 pl-2 pr-1.5 py-1.5 rounded-full no-underline text-white cursor-pointer border border-white/25 active:scale-[0.97] transition-transform"
                    style={{ background: 'linear-gradient(135deg, rgba(58,99,214,0.9) 0%, rgba(22,40,108,0.95) 100%)', boxShadow: '0 10px 28px rgba(30,60,160,0.5), inset 0 1px 1px rgba(255,255,255,0.32)' }}
                  >
                    <span className="cta-shine" aria-hidden="true" />
                    <span className="relative w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 bg-white/[0.14] border border-white/30" style={{ boxShadow: 'inset 0 1px 1px rgba(255,255,255,0.35)' }}>
                      <svg viewBox="0 0 24 24" className="w-[19px] h-[19px] fill-white -translate-x-px" aria-hidden="true">
                        <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z" />
                      </svg>
                    </span>
                    <span className="relative flex-1 min-w-0 leading-tight text-left">
                      <span className="block text-[0.92rem] font-semibold tracking-wide">Join Telegram Channel</span>
                      <span className="block text-[0.68rem] font-medium text-white/60">@auraffxofficial</span>
                    </span>
                    <span className="relative w-10 h-10 rounded-full bg-white flex items-center justify-center text-[#1a2f78] flex-shrink-0">
                      <ArrowUpRight size={18} strokeWidth={2.4} />
                    </span>
                  </a>
                </div>

                {/* Social links */}
                <div className="relative mt-5 grid grid-cols-2 gap-2.5">
                  {[
                    { cls: 'social-card-yt', href: 'https://www.youtube.com/@devyasin', name: 'YouTube', handle: '@devyasin', delay: '0.32s', dur: '6s', bg: '#FF0000', icon: 'yt' },
                    { cls: 'social-card-tt', href: 'https://www.tiktok.com/@devxyasin', name: 'TikTok', handle: '@devxyasin', delay: '0.38s', dur: '6.8s', bg: '#010101', icon: 'tt' },
                  ].map((c) => (
                    <div key={c.name} className="pop-in" style={sv({ animationDelay: c.delay, '--fy': '18px', '--fs': 0.96 })}>
                      <div className="hero-float" style={{ animationDuration: c.dur }}>
                        <a
                          href={c.href}
                          target="_blank"
                          rel="noopener noreferrer"
                          title={`Visit ${c.name}: ${c.handle}`}
                          className={`${c.cls} group flex items-center gap-2.5 p-2.5 pr-3 rounded-[1.1rem] bg-white/[0.06] no-underline select-none relative overflow-hidden active:scale-[0.96] cursor-pointer`}
                        >
                          <div className="absolute inset-0 bg-gradient-to-br from-white/15 via-transparent to-transparent pointer-events-none" />
                          <span className="relative w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 border border-white/90" style={{ background: c.bg }}>
                            <svg viewBox="0 0 24 24" className="w-[17px] h-[17px] fill-white" aria-hidden="true">
                              {c.icon === 'yt' ? (
                                <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
                              ) : (
                                <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 3 15.68 6.34 6.34 0 0 0 9.34 22a6.33 6.33 0 0 0 6.33-6.33V9.2a8.16 8.16 0 0 0 4.92 1.63V7.39a4.85 4.85 0 0 1-1-.7z" />
                              )}
                            </svg>
                          </span>
                          <span className="relative flex-1 min-w-0 leading-tight">
                            <span className="block text-[0.82rem] font-bold text-white">{c.name}</span>
                            <span className="block text-[0.66rem] font-medium text-white/55 truncate">{c.handle}</span>
                          </span>
                          <ArrowUpRight size={15} className="relative text-[#9DB8FF] flex-shrink-0" />
                        </a>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Watch intro: compact glass row with the play badge (animated light border like the cards) */}
                <div className="hero-in relative mt-4" style={{ animationDelay: '0.44s' }}>
                  <div
                    role="button"
                    tabIndex={0}
                    aria-label="Watch this video"
                    onClick={(e) => {
                      // the badge button handles its own click; anywhere else on the row also opens the video
                      if ((e.target as HTMLElement).closest('button')) return;
                      window.dispatchEvent(new CustomEvent('dy:open-video'));
                    }}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        window.dispatchEvent(new CustomEvent('dy:open-video'));
                      }
                    }}
                    className="relative overflow-hidden rounded-[1.3rem] pl-3 pr-4 py-3 flex items-center gap-4 cursor-pointer active:scale-[0.985] transition-transform"
                    style={{
                      background: 'radial-gradient(70% 140% at 12% 50%, rgba(80,120,255,0.20) 0%, rgba(80,120,255,0) 70%), linear-gradient(160deg, rgba(255,255,255,0.07) 0%, rgba(255,255,255,0.015) 60%, rgba(255,255,255,0.04) 100%)',
                      boxShadow: '0 12px 30px rgba(0,0,0,0.32), inset 0 1px 1px rgba(255,255,255,0.14)',
                    }}
                  >
                    <div className="border-wrapper" style={{ borderRadius: '1.3rem', padding: '1.5px' }}>
                      <div className="card-border-animation" />
                    </div>

                    <div className="relative flex-shrink-0">
                      <DevYasinXPlayer small />
                    </div>

                    <div className="relative flex-1 min-w-0 leading-tight">
                      <div className="flex items-center gap-1.5 text-[9.5px] font-semibold tracking-[0.22em] uppercase text-[#9DB8FF]">
                        <span className="w-1.5 h-1.5 rounded-full bg-[#6F9BFF] animate-ping" />
                        <span>Official Video</span>
                      </div>
                      <div className="mt-1.5 text-[1.05rem] font-medium tracking-tight text-white">Watch this video</div>
                      <div className="mt-0.5 text-[0.72rem] text-white/50">Tap anywhere to play</div>
                    </div>
                  </div>
                </div>

                {/* Developer code window: lines appear one after another, then the cycle repeats (opacity/transform only) */}
                <div className="mt-auto pt-4 pb-1 select-none">
                  <HoldDrag
                    className="relative overflow-hidden rounded-[1.2rem] border border-white/[0.16]"
                    style={{
                      background: 'radial-gradient(80% 90% at 100% 0%, rgba(80,120,255,0.20) 0%, rgba(80,120,255,0) 65%), linear-gradient(160deg, rgba(255,255,255,0.08) 0%, rgba(255,255,255,0.02) 100%)',
                      boxShadow: 'inset 0 1px 1px rgba(255,255,255,0.18), 0 14px 32px rgba(0,0,0,0.35)',
                    }}
                  >
                    {/* title bar */}
                    <div className="flex items-center gap-1.5 px-3.5 h-9 border-b border-white/10 bg-white/[0.03]">
                      <span className="w-2 h-2 rounded-full bg-[#9DB8FF]/70" />
                      <span className="w-2 h-2 rounded-full bg-[#6F9BFF]/55" />
                      <span className="w-2 h-2 rounded-full bg-white/25" />
                      <span className="ml-auto text-[10px] font-semibold tracking-[0.12em] text-white/45" style={{ fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Consolas, monospace' }}>dev-yasin.js</span>
                    </div>

                    {/* code */}
                    <div className="px-3.5 py-3 text-[0.74rem] leading-[1.75] whitespace-pre" style={{ fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Consolas, monospace' }}>
                      {[
                        <><span className="text-[#9DB8FF]">const</span> <span className="text-white">dev</span> <span className="text-white/50">=</span> <span className="text-white/60">{'{'}</span></>,
                        <>  <span className="text-[#C4D5FF]">name</span><span className="text-white/50">:</span> <span className="text-[#7FE3B8]">"Dev Yasin"</span><span className="text-white/50">,</span></>,
                        <>  <span className="text-[#C4D5FF]">role</span><span className="text-white/50">:</span> <span className="text-[#7FE3B8]">"Creative Developer"</span><span className="text-white/50">,</span></>,
                        <>  <span className="text-[#C4D5FF]">builds</span><span className="text-white/50">:</span> <span className="text-white/60">[</span><span className="text-[#7FE3B8]">"Web"</span><span className="text-white/50">,</span> <span className="text-[#7FE3B8]">"APK"</span><span className="text-white/50">,</span> <span className="text-[#7FE3B8]">"Bot"</span><span className="text-white/50">,</span> <span className="text-[#7FE3B8]">"API"</span><span className="text-white/60">]</span><span className="text-white/50">,</span></>,
                        <>  <span className="text-[#C4D5FF]">free</span><span className="text-white/50">:</span> <span className="text-[#6F9BFF]">true</span><span className="text-white/50">,</span></>,
                        <><span className="text-white/60">{'}'}</span><span className="text-white/50">;</span><span className="code-cursor inline-block w-[7px] h-[1em] -mb-[2px] ml-1 bg-[#9DB8FF]" /></>,
                      ].map((line, i) => (
                        <div key={i} className="code-line flex" style={{ animationDelay: `${i * 0.55}s` }}>
                          <span className="inline-block w-5 mr-2 text-right text-white/25">{i + 1}</span>
                          <span>{line}</span>
                        </div>
                      ))}
                    </div>
                  </HoldDrag>
                </div>

                {/* scroll cue: tells the visitor there is more below the first screen */}
                <div className="pt-4 pb-1 flex flex-col items-center gap-1.5 text-white/40">
                  <span className="text-[9px] font-semibold tracking-[0.3em] uppercase">Scroll</span>
                  <span className="scroll-cue block w-px h-5 bg-gradient-to-b from-[#9DB8FF] to-transparent" />
                </div>
                </div>

                {/* ===== Below the first screen: Explore (list design) ===== */}
                <div className="hero-in relative mt-8" style={{ animationDelay: '0.5s' }}>
                  <div className="flex items-center gap-3 mb-1">
                    <span className="text-[10px] font-semibold tracking-[0.24em] uppercase text-white/45">Explore</span>
                    <span className="flex-1 h-px bg-white/10" />
                  </div>
                  {[
                    { n: '01', name: 'Free Website', value: 'build & host', go: 'Free Web' },
                    { n: '02', name: 'APK Building', value: 'apps for Android', go: 'APK' },
                    { n: '03', name: 'Bot Making', value: 'smart automation', go: 'BOT' },
                    { n: '04', name: 'API Key', value: 'instant access', go: 'API' },
                  ].map((it) => (
                    <button
                      key={it.n}
                      type="button"
                      onClick={() => handleNavItemClick(it.go)}
                      className="group w-full flex items-center gap-4 py-3.5 bg-transparent border-0 border-b border-white/10 text-left cursor-pointer active:bg-white/[0.04] transition-colors"
                    >
                      <span className="inline-block w-7 text-[0.62rem] font-bold tracking-[0.12em] text-[#6F9BFF]" style={{ fontFamily: "'Orbitron', sans-serif" }}>{it.n}</span>
                      <span className="flex-1 min-w-0">
                        <span className="block text-[1.02rem] font-medium tracking-tight text-white">{it.name}</span>
                        <span className="block text-[0.7rem] text-white/45">{it.value}</span>
                      </span>
                      <ArrowUpRight size={17} className="text-[#9DB8FF] flex-shrink-0" />
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* ===== DESKTOP LAYOUT ===== */}
            {isDesktop && (
              <div className="w-full">
                <TitleStack desktop />

                <div className="absolute inset-0 w-full h-full pointer-events-none z-30">
                  {/* YouTube */}
                  <div className="absolute top-[26%] left-[4%] md:left-[5%] lg:left-[6%] pointer-events-auto z-40 pop-in" style={sv({ animationDelay: '0.32s', '--fx': '-60px', '--fr': '-22deg', '--tr': '-9deg', '--fs': 0.85 })}>
                    <div>
                      <div className="hero-float" style={{ animationDuration: '5s' }}>
                        <a
                          href="https://www.youtube.com/@devyasin"
                          target="_blank"
                          rel="noopener noreferrer"
                          title="Visit YouTube: @devyasin"
                          className="social-card-yt w-58 md:w-66 lg:w-72 aspect-[1/1.18] bg-white/[0.08] rounded-[2.4rem] md:rounded-[2.8rem] p-6 md:p-7 flex flex-col items-center justify-center hover:scale-105 hover:bg-white/[0.12] cursor-pointer group no-underline select-none block"
                        >
                          <YouTubeLogo />
                          <SocialText handle="@devyasin" hover="group-hover:text-[#C4D5FF]" desktop />
                        </a>
                      </div>
                    </div>
                  </div>

                  {/* TikTok */}
                  <div className="absolute top-[-4%] right-[4%] md:right-[5%] lg:right-[6%] pointer-events-auto z-40 pop-in" style={sv({ animationDelay: '0.38s', '--fx': '60px', '--fr': '22deg', '--tr': '9deg', '--fs': 0.85 })}>
                    <div>
                      <div className="hero-float" style={{ animationDuration: '6s', animationDelay: '0.4s' }}>
                        <a
                          href="https://www.tiktok.com/@devxyasin"
                          target="_blank"
                          rel="noopener noreferrer"
                          title="Visit TikTok: @devxyasin"
                          className="social-card-tt w-58 md:w-66 lg:w-72 aspect-[1/1.18] bg-white/[0.08] rounded-[2.2rem] md:rounded-[2.8rem] p-6 md:p-7 flex flex-col items-center justify-center hover:scale-105 hover:bg-white/[0.12] cursor-pointer group no-underline select-none block"
                        >
                          <TikTokLogo />
                          <SocialText handle="@devxyasin" hover="group-hover:text-[#C4D5FF]" desktop />
                        </a>
                      </div>
                    </div>
                  </div>

                  {/* Decorative arrows */}
                  <div className="pop-in absolute bottom-[2%] left-[1%] md:left-[2%] w-28 h-28 md:w-34 md:h-34 z-20 pointer-events-none" style={sv({ animationDelay: '0.48s', '--fr': '-20deg', '--fs': 0.7 })}>
                    <ArrowGreenLeft />
                  </div>
                  <div className="pop-in absolute top-[0%] right-[1%] md:right-[2%] w-28 h-28 md:w-34 md:h-34 z-20 pointer-events-none" style={sv({ animationDelay: '0.54s', '--fr': '20deg', '--fs': 0.7 })}>
                    <ArrowGreenRight />
                  </div>

                  {/* Player badge */}
                  <div className="pop-in absolute bottom-[-5%] right-[11%] md:right-[13%] z-50 pointer-events-auto" style={sv({ animationDelay: '0.44s', '--fr': '35deg', '--fs': 0.6 })}>
                    <DevYasinXPlayer />
                  </div>
                </div>
              </div>
            )}
          </div>
        </main>
      </div>
    </LazyMotion>
  );
};
