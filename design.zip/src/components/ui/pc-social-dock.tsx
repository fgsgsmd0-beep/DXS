import React, { useEffect, useRef, useState } from "react";
import { m, AnimatePresence } from "motion/react";
import { DevYasinXPlayer } from "./video-music-player";
import { playMeow } from "../../lib/meow";

/**
 * PC only: small cat launcher in the bottom-right corner.
 *
 * Closed  -> just the cat.
 * Clicked -> three round icons pop up above the cat: video, TikTok, YouTube.
 * Icons only, no text (the names are in the tooltips / aria-labels).
 *
 * The video modal itself still lives in video-music-player.tsx; it is mounted here
 * in "headless" mode (no trigger button) and opened with the 'dy:open-video' event.
 */

const YT_URL = "https://www.youtube.com/@devyasin";
const TT_URL = "https://www.tiktok.com/@devxyasin";

const PLAY_PATH =
  "M8 5.6v12.8a1 1 0 0 0 1.52.86l10.3-6.4a1 1 0 0 0 0-1.72L9.52 4.74A1 1 0 0 0 8 5.6z";
const YT_LOGO_PATH =
  "M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z";
const TT_PATH =
  "M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 3 15.68 6.34 6.34 0 0 0 9.34 22a6.33 6.33 0 0 0 6.33-6.33V9.2a8.16 8.16 0 0 0 4.92 1.63V7.39a4.85 4.85 0 0 1-1-.7z";


/** Little cat face (site blue palette). Eyes blink; they turn into happy arcs while the menu is open. */
const CatFace: React.FC<{ uid?: string }> = ({ uid = "" }) => (
  <svg viewBox="0 0 64 58" className="pc-cat" aria-hidden="true">
    <defs>
      <linearGradient id={`catFur${uid}`} x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#5a85f0" />
        <stop offset="0.55" stopColor="#3a63d6" />
        <stop offset="1" stopColor="#1a2f78" />
      </linearGradient>
      <radialGradient id={`catCheek${uid}`} cx="0.5" cy="0.3" r="0.6">
        <stop offset="0" stopColor="#ffffff" stopOpacity="0.28" />
        <stop offset="1" stopColor="#ffffff" stopOpacity="0" />
      </radialGradient>
    </defs>
    {/* ears + head in one shape */}
    <path
      className="pc-cat-head"
      d="M7 27 L9.5 4.5 Q10 2 12.2 3.3 L26 13.2 Q32 11.8 38 13.2 L51.8 3.3 Q54 2 54.5 4.5 L57 27 Q59 39 49 47.5 Q41 54 32 54 Q23 54 15 47.5 Q5 39 7 27 Z"
      fill={`url(#catFur${uid})`}
      stroke="#9DB8FF"
      strokeWidth="1.6"
      strokeLinejoin="round"
    />
    <ellipse cx="32" cy="38" rx="22" ry="15" fill={`url(#catCheek${uid})`} />
    {/* inner ears */}
    <path className="pc-cat-ear pc-cat-ear-l" d="M12.8 9.5 L13.6 21 L23 14.6 Z" fill="#C4D5FF" opacity="0.85" />
    <path className="pc-cat-ear pc-cat-ear-r" d="M51.2 9.5 L50.4 21 L41 14.6 Z" fill="#C4D5FF" opacity="0.85" />
    {/* forehead stripes */}
    <g stroke="#9DB8FF" strokeWidth="1.6" strokeLinecap="round" opacity="0.8">
      <path d="M32 15.5 V21" />
      <path d="M26.5 16.8 L27.8 21.2" />
      <path d="M37.5 16.8 L36.2 21.2" />
    </g>
    {/* eyes open */}
    <g className="pc-cat-eyes">
      <ellipse cx="21.5" cy="30" rx="5" ry="6" fill="#EAF1FF" />
      <ellipse cx="42.5" cy="30" rx="5" ry="6" fill="#EAF1FF" />
      <ellipse cx="22" cy="30.6" rx="2.6" ry="4.2" fill="#0a1440" />
      <ellipse cx="43" cy="30.6" rx="2.6" ry="4.2" fill="#0a1440" />
      <circle cx="23" cy="28.2" r="1.2" fill="#fff" />
      <circle cx="44" cy="28.2" r="1.2" fill="#fff" />
    </g>
    {/* eyes happy (menu open) */}
    <g className="pc-cat-happy" fill="none" stroke="#EAF1FF" strokeWidth="2.4" strokeLinecap="round">
      <path d="M16.5 32 Q21.5 25 26.5 32" />
      <path d="M37.5 32 Q42.5 25 47.5 32" />
    </g>
    {/* nose + mouth */}
    <path d="M29.6 37 H34.4 L32 40 Z" fill="#C4D5FF" stroke="#C4D5FF" strokeWidth="1" strokeLinejoin="round" />
    <path className="pc-cat-smile" d="M32 40 Q29.5 44.5 25.5 42 M32 40 Q34.5 44.5 38.5 42" fill="none" stroke="#C4D5FF" strokeWidth="1.5" strokeLinecap="round" />
    {/* whiskers */}
    <g className="pc-cat-whiskers" stroke="#DCE6FF" strokeWidth="1.1" strokeLinecap="round" opacity="0.85">
      <path d="M15 38 L3 35.5" />
      <path d="M15.5 42 L4 44.5" />
      <path d="M49 38 L61 35.5" />
      <path d="M48.5 42 L60 44.5" />
    </g>
  </svg>
);

export const PcSocialDock: React.FC = () => {
  const [open, setOpen] = useState(false);
  const rootRef = useRef<HTMLDivElement>(null);

  // Close on outside click and on Escape
  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      if (rootRef.current && !rootRef.current.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  const items = [
    {
      key: "youtube",
      label: "YouTube",
      cls: "pc-dock-yt",
      href: YT_URL,
      icon: (
        <svg viewBox="0 0 24 24" className="w-[17px] h-[17px]" aria-hidden="true">
          <path
            fill="#fff"
            d={YT_LOGO_PATH}
          />
        </svg>
      ),
    },
    {
      key: "tiktok",
      label: "TikTok",
      cls: "pc-dock-tt",
      href: TT_URL,
      icon: (
        <svg viewBox="0 0 24 24" className="w-[17px] h-[17px] pc-dock-tt-svg" aria-hidden="true">
          <path fill="#fff" d={TT_PATH} />
        </svg>
      ),
    },
    {
      key: "video",
      label: "Watch video",
      cls: "pc-dock-play",
      onClick: () => {
        setOpen(false);
        window.dispatchEvent(new CustomEvent("dy:open-video"));
      },
      icon: (
        <svg viewBox="0 0 24 24" className="w-[15px] h-[15px] translate-x-[0.5px]" aria-hidden="true">
          <path fill="#fff" d={PLAY_PATH} />
        </svg>
      ),
    },
  ];

  return (
    <>
      <div ref={rootRef} className="pc-dock" data-open={open ? "" : undefined}>
        {/* YouTube / TikTok / video (pop up above the cat) */}
        <div className="pc-dock-social">
          <AnimatePresence>
            {open &&
              items.map((it, i) => {
                const common = {
                  "aria-label": it.label,
                  title: it.label,
                  className: `pc-dock-btn ${it.cls}`,
                };
                const motionProps = {
                  initial: { opacity: 0, y: 18, scale: 0.5 },
                  animate: { opacity: 1, y: 0, scale: 1 },
                  exit: { opacity: 0, y: 14, scale: 0.5, transition: { duration: 0.14 } },
                  transition: { type: "spring" as const, stiffness: 520, damping: 26, delay: i * 0.05 },
                };
                return it.href ? (
                  <m.a
                    key={it.key}
                    {...common}
                    {...motionProps}
                    href={it.href}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    {it.icon}
                  </m.a>
                ) : (
                  <m.button key={it.key} {...common} {...motionProps} type="button" onClick={it.onClick}>
                    {it.icon}
                  </m.button>
                );
              })}
          </AnimatePresence>
        </div>

        {/* The small cat launcher */}
        <button
          type="button"
          onClick={() => {
            playMeow();
            setOpen((v) => !v);
          }}
          aria-label={open ? "Close shortcuts" : "Open shortcuts"}
          aria-expanded={open}
          title={open ? "Close" : "Shortcuts"}
          className="pc-dock-main"
        >
          <CatFace />
        </button>
      </div>

      {/* Video modal only (no trigger button); opened by the 'dy:open-video' event */}
      <DevYasinXPlayer headless />
    </>
  );
};

export default PcSocialDock;
