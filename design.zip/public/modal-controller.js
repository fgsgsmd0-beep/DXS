(function() {
    'use strict';

    var ALL_SUBVIEWS = [
        'modalViewResources',
        'modalViewPassword',
        'modalViewComingSoon',
        'modalViewVersion2',
        'modalViewVersion3',
        'modalViewVersion3_5',
        'modalViewVersion4_0',
        'modalViewVersion4_5',
        'modalViewVersion5_0',
        'modalViewVersion5_5',
        'modalViewVersion6_0',
        'modalViewVersion6_5',
        'modalViewVersion7_0',
        'modalViewVersion7_5',
        'modalViewVersion8_0',
        'modalViewVersion8_5',
        'modalViewVersion9_0',
        'modalViewVersion9_5',
        'modalViewVersion10_0',
        'modalViewVersion10_5',
        'modalViewVersion11_0',
        'modalViewVersion11_5',
        'modalViewVersion12_0',
        'modalViewVersion12_5',
        'modalViewVersion13_0',
        'modalViewVersion13_5',
        'modalViewVersion14_0'
    ];

    function hideAllVersionSubviews() {
        for (var i = 0; i < ALL_SUBVIEWS.length; i++) {
            var el = document.getElementById(ALL_SUBVIEWS[i]);
            if (el) el.style.display = 'none';
        }
    }

    function getVersionViewId(ver) {
        if (!ver) return 'modalViewComingSoon';
        var v = String(ver).trim();
        if (v === '1' || v === '1.0') return 'modalViewResources';
        if (v === '2' || v === '2.0') return 'modalViewVersion2';
        if (v === '2.5') return 'modalViewComingSoon';
        if (v === '3' || v === '3.0') return 'modalViewVersion3';
        if (v === '3.5') return 'modalViewVersion3_5';
        if (v === '4' || v === '4.0') return 'modalViewVersion4_0';
        if (v === '4.5') return 'modalViewVersion4_5';
        if (v === '5' || v === '5.0') return 'modalViewVersion5_0';
        if (v === '5.5') return 'modalViewVersion5_5';
        if (v === '6' || v === '6.0') return 'modalViewVersion6_0';
        if (v === '6.5') return 'modalViewVersion6_5';
        if (v === '7' || v === '7.0') return 'modalViewVersion7_0';
        if (v === '7.5') return 'modalViewVersion7_5';
        if (v === '8' || v === '8.0') return 'modalViewVersion8_0';
        if (v === '8.5') return 'modalViewVersion8_5';
        if (v === '9' || v === '9.0') return 'modalViewVersion9_0';
        if (v === '9.5') return 'modalViewVersion9_5';
        if (v === '10' || v === '10.0') return 'modalViewVersion10_0';
        if (v === '10.5') return 'modalViewVersion10_5';
        if (v === '11' || v === '11.0') return 'modalViewVersion11_0';
        if (v === '11.5') return 'modalViewVersion11_5';
        if (v === '12' || v === '12.0') return 'modalViewVersion12_0';
        if (v === '12.5') return 'modalViewVersion12_5';
        if (v === '13' || v === '13.0') return 'modalViewVersion13_0';
        if (v === '13.5') return 'modalViewVersion13_5';
        if (v === '14' || v === '14.0') return 'modalViewVersion14_0';
        return 'modalViewComingSoon';
    }

    function openVersionSubView(ver) {
        var targetId = getVersionViewId(ver);
        var vModal = document.getElementById('versionsModal');
        if (!vModal) return;

        var viewList = document.getElementById('modalViewVersions');
        if (viewList) viewList.style.display = 'none';

        hideAllVersionSubviews();

        var targetEl = document.getElementById(targetId);
        if (targetEl) {
            targetEl.style.display = 'block';
        } else {
            var cs = document.getElementById('modalViewComingSoon');
            if (cs) cs.style.display = 'block';
        }

        vModal.classList.add('active');
        document.body.style.overflow = 'hidden';

        var content = vModal.querySelector('.modal-content');
        if (content) content.scrollTop = 0;

        history.replaceState(null, null, '?version-' + ver);
    }

    function openVersionsList() {
        var vModal = document.getElementById('versionsModal');
        if (!vModal) return;

        var viewList = document.getElementById('modalViewVersions');
        if (viewList) viewList.style.display = 'block';

        hideAllVersionSubviews();

        var passInput = document.getElementById('unlockPassword');
        if (passInput) passInput.value = '';
        var passError = document.getElementById('passwordError');
        if (passError) passError.textContent = '';

        vModal.classList.add('active');
        document.body.style.overflow = 'hidden';

        var content = vModal.querySelector('.modal-content');
        if (content) content.scrollTop = 0;

        if (window.location.search !== '?versions' && !window.location.search.startsWith('?version-')) {
            history.replaceState(null, null, '?versions');
        }
    }

    function openBotModal(ver) {
        var bModal = document.getElementById('botVersionsModal');
        if (!bModal) return;

        var botList = document.getElementById('modalViewBotVersions');
        var botR1 = document.getElementById('modalViewBotResources');
        var botR2 = document.getElementById('modalViewBotV2');

        if (ver === '1') {
            if (botList) botList.style.display = 'none';
            if (botR1) botR1.style.display = 'block';
            if (botR2) botR2.style.display = 'none';
            history.replaceState(null, null, '?bot-version-1');
        } else if (ver === '2') {
            if (botList) botList.style.display = 'none';
            if (botR1) botR1.style.display = 'none';
            if (botR2) botR2.style.display = 'block';
            history.replaceState(null, null, '?bot-version-2');
        } else {
            if (botList) botList.style.display = 'block';
            if (botR1) botR1.style.display = 'none';
            if (botR2) botR2.style.display = 'none';
            if (window.location.search !== '?bot-versions' && !window.location.search.startsWith('?bot-version-')) {
                history.replaceState(null, null, '?bot-versions');
            }
        }

        bModal.classList.add('active');
        document.body.style.overflow = 'hidden';

        var content = bModal.querySelector('.modal-content');
        if (content) content.scrollTop = 0;
    }

    function openSecurityModal() {
        var sModal = document.getElementById('securityModal');
        if (!sModal) return;
        sModal.classList.add('active');
        document.body.style.overflow = 'hidden';
        var content = sModal.querySelector('.modal-content');
        if (content) content.scrollTop = 0;
        if (window.location.search !== '?security') {
            history.replaceState(null, null, '?security');
        }
    }

    function openReviewModal() {
        var rModal = document.getElementById('reviewModal');
        if (!rModal) return;
        rModal.classList.add('active');
        document.body.style.overflow = 'hidden';
        var content = rModal.querySelector('.modal-content');
        if (content) content.scrollTop = 0;
        if (window.location.search !== '?review') {
            history.replaceState(null, null, '?review');
        }
    }

    function openPcToolsModal() {
        var pModal = document.getElementById('pcToolsModal');
        if (!pModal) return;
        pModal.classList.add('active');
        document.body.style.overflow = 'hidden';
        var content = pModal.querySelector('.modal-content');
        if (content) content.scrollTop = 0;
        if (window.location.search !== '?pc-tools') {
            history.replaceState(null, null, '?pc-tools');
        }
    }

    function closeAllModals() {
        document.querySelectorAll('.modal-overlay.active').forEach(function(m) {
            m.classList.remove('active');
        });
        var np = document.getElementById('modalViewNotepad');
        if (np) np.style.display = 'none';
        var cw = document.getElementById('customWizardModal');
        if (cw) cw.style.display = 'none';
        var cs = document.getElementById('customSaveModal');
        if (cs) cs.style.display = 'none';
        document.body.style.overflow = '';
        history.replaceState(null, null, window.location.pathname);
    }

    // Global Event Delegation for ALL Click Interactions
    document.addEventListener('click', function(e) {
        // 1. Back button in Versions Modal
        var verBackBtn = e.target.closest('#backToVersionsBtn, #backToVersionsComingSoonBtn, [id^="backToVersionsBtn"]');
        if (!verBackBtn && e.target.closest('#versionsModal') && e.target.closest('.back-btn')) {
            verBackBtn = e.target.closest('.back-btn');
        }
        if (verBackBtn) {
            e.preventDefault();
            openVersionsList();
            history.replaceState(null, null, '?versions');
            return;
        }

        // 2. Back button in Bot Modal
        var botBackBtn = e.target.closest('#backToBotVersionsBtn, #backToBotVersionsBtnV2');
        if (!botBackBtn && e.target.closest('#botVersionsModal') && e.target.closest('.back-btn')) {
            botBackBtn = e.target.closest('.back-btn');
        }
        if (botBackBtn) {
            e.preventDefault();
            openBotModal();
            history.replaceState(null, null, '?bot-versions');
            return;
        }

        // 3. Version VIEW buttons (Inside Versions Modal)
        var versionBtn = e.target.closest('.version-view-btn');
        if (versionBtn) {
            // Buttons that carry a real link (target="_blank") just open it in a new tab
            if (versionBtn.getAttribute('target') === '_blank' && versionBtn.getAttribute('href') && versionBtn.getAttribute('href') !== '#') {
                return;
            }
            e.preventDefault();
            var ver = versionBtn.getAttribute('data-version');
            openVersionSubView(ver);
            return;
        }

        // 4. Bot Version VIEW buttons
        var botVBtn = e.target.closest('.bot-version-view-btn');
        if (botVBtn) {
            e.preventDefault();
            var bVer = botVBtn.getAttribute('data-bot-version');
            openBotModal(bVer);
            return;
        }

        // 5. Card: Free Website
        var vCardBtn = e.target.closest('#viewBtn');
        if (vCardBtn) {
            e.preventDefault();
            openVersionsList();
            return;
        }

        // 6. Card: Bot Making
        var bCardBtn = e.target.closest('#botViewBtn');
        if (bCardBtn) {
            e.preventDefault();
            openBotModal();
            return;
        }

        // 7. Card: Security
        var sCardBtn = e.target.closest('#securityViewBtn');
        if (sCardBtn) {
            e.preventDefault();
            openSecurityModal();
            return;
        }

        // 8. Card: Review Project
        var rCardBtn = e.target.closest('#reviewViewBtn');
        if (rCardBtn) {
            e.preventDefault();
            openReviewModal();
            return;
        }

        // 8b. Card: PC Tools
        var pCardBtn = e.target.closest('#pcToolsViewBtn');
        if (pCardBtn) {
            e.preventDefault();
            openPcToolsModal();
            return;
        }

        // 9. Modal Close Buttons
        var closeBtn = e.target.closest('.modal-close, #closeModalBtn, #closeBotModalBtn, #closeSecurityModalBtn, #closeReviewModalBtn, #closePcToolsModalBtn');
        if (closeBtn) {
            e.preventDefault();
            closeAllModals();
            return;
        }

        // 10. Click on Modal Overlay Backdrop
        if (e.target.classList && e.target.classList.contains('modal-overlay')) {
            closeAllModals();
            return;
        }

        // 11. Password Submission
        var pwBtn = e.target.closest('#submitPasswordBtn');
        if (pwBtn) {
            e.preventDefault();
            var pwInput = document.getElementById('unlockPassword');
            var pwError = document.getElementById('passwordError');
            if (pwInput && pwInput.value.trim() === '36') {
                var pwScreen = document.getElementById('modalViewPassword');
                if (pwScreen) pwScreen.style.display = 'none';
                var resScreen = document.getElementById('modalViewResources');
                if (resScreen) resScreen.style.display = 'block';
                if (pwError) pwError.textContent = '';
            } else if (pwError) {
                pwError.textContent = 'Incorrect Password! Please try again.';
            }
            return;
        }

        // 12. Notepad Open Buttons
        var openNpBtn = e.target.closest('#openNotepadBtn, #openNotepadBtn2, #openNotepadBtn5_0, #openNotepadBtn5_5');
        if (openNpBtn) {
            e.preventDefault();
            history.pushState(null, null, '?notepad');
            handleSearchRouting();
            return;
        }

        // 13. Notepad Back Button
        var backNpBtn = e.target.closest('#backToResourcesBtn');
        if (backNpBtn) {
            e.preventDefault();
            var npEdit = document.getElementById('notepadEditState');
            var npUp = document.getElementById('notepadUploadState');
            var npSave = document.getElementById('saveFileBtn');
            var npArea = document.getElementById('notepadTextarea');
            var npView = document.getElementById('modalViewNotepad');
            if (npEdit && npEdit.style.display === 'flex') {
                npEdit.style.display = 'none';
                if (npUp) npUp.style.display = 'flex';
                if (npSave) npSave.style.display = 'none';
                if (npArea) npArea.value = '';
            } else {
                if (npView) npView.style.display = 'none';
                if (window.location.search === '?notepad') {
                    history.replaceState(null, null, window.location.pathname);
                }
            }
            return;
        }

        // 14. Notepad Save / Cancel Buttons
        var saveBtn = e.target.closest('#saveFileBtn');
        if (saveBtn) {
            e.preventDefault();
            var customSaveModal = document.getElementById('customSaveModal');
            var saveFileNameInput = document.getElementById('saveFileNameInput');
            var saveFileExtension = document.getElementById('saveFileExtension');
            var curName = window.notepadCurrentFileName || 'notepad_edit.txt';
            var ext = '.txt';
            var baseName = curName;
            var dotIdx = curName.lastIndexOf('.');
            if (dotIdx !== -1) {
                ext = curName.substring(dotIdx);
                baseName = curName.substring(0, dotIdx);
            }
            if (customSaveModal && saveFileNameInput && saveFileExtension) {
                saveFileExtension.textContent = ext;
                saveFileNameInput.value = baseName;
                customSaveModal.style.display = 'flex';
                saveFileNameInput.focus();
                saveFileNameInput.select();
            }
            return;
        }

        var cancelSave = e.target.closest('#cancelSaveBtn');
        if (cancelSave) {
            e.preventDefault();
            var customSave = document.getElementById('customSaveModal');
            if (customSave) customSave.style.display = 'none';
            return;
        }

        var confirmSave = e.target.closest('#confirmSaveBtn');
        if (confirmSave) {
            e.preventDefault();
            var sInput = document.getElementById('saveFileNameInput');
            var sExt = document.getElementById('saveFileExtension');
            var sArea = document.getElementById('notepadTextarea');
            var base = sInput ? sInput.value.trim() : 'file';
            if (!base) base = 'file';
            var extStr = sExt ? sExt.textContent : '.txt';
            var txt = sArea ? sArea.value : '';
            var blob = new Blob([txt], { type: 'text/plain' });
            var a = document.createElement('a');
            a.href = URL.createObjectURL(blob);
            a.download = base + extStr;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            var cSave = document.getElementById('customSaveModal');
            if (cSave) cSave.style.display = 'none';
            return;
        }
    });

    // Global keyboard shortcut
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeAllModals();
        }
    });

    // Notepad file upload listener setup
    function initNotepadInput() {
        var fileInput = document.getElementById('notepadFileInput');
        var textarea = document.getElementById('notepadTextarea');
        var uploadState = document.getElementById('notepadUploadState');
        var editState = document.getElementById('notepadEditState');
        var saveBtn = document.getElementById('saveFileBtn');
        var lineNumbers = document.getElementById('lineNumbers');

        function updateLines() {
            if (!textarea || !lineNumbers) return;
            var count = textarea.value.split('\n').length;
            var html = Array.from({ length: count }, function(_, i) { return i + 1; }).join('<br>');
            lineNumbers.innerHTML = html;
        }

        if (fileInput) {
            fileInput.addEventListener('change', function(e) {
                var f = e.target.files && e.target.files[0];
                if (!f) return;
                window.notepadCurrentFileName = f.name;
                var reader = new FileReader();
                reader.onload = function(ev) {
                    if (textarea) textarea.value = ev.target.result;
                    if (uploadState) uploadState.style.display = 'none';
                    if (editState) editState.style.display = 'flex';
                    if (saveBtn) saveBtn.style.display = 'flex';
                    updateLines();
                };
                reader.readAsText(f);
                e.target.value = '';
            });
        }

        if (textarea) {
            textarea.addEventListener('input', updateLines);
            textarea.addEventListener('scroll', function() {
                if (lineNumbers) lineNumbers.scrollTop = textarea.scrollTop;
            });
            textarea.addEventListener('keydown', function(e) {
                if (e.key === 'Tab') {
                    e.preventDefault();
                    var start = this.selectionStart;
                    var end = this.selectionEnd;
                    this.value = this.value.substring(0, start) + '\t' + this.value.substring(end);
                    this.selectionStart = this.selectionEnd = start + 1;
                    updateLines();
                }
            });
        }
    }

    // Deep linking and query routing
    function handleSearchRouting() {
        var query = window.location.search;
        if (!query) return;

        var param = query.substring(1);
        if (param === 'notepad') {
            var np = document.getElementById('modalViewNotepad');
            var up = document.getElementById('notepadUploadState');
            var ed = document.getElementById('notepadEditState');
            var sv = document.getElementById('saveFileBtn');
            if (np) {
                np.style.display = 'flex';
                if (up) up.style.display = 'flex';
                if (ed) ed.style.display = 'none';
                if (sv) sv.style.display = 'none';
            }
            return;
        }

        if (param === 'versions') {
            openVersionsList();
            return;
        }

        if (param.startsWith('version-')) {
            var v = param.split('version-')[1];
            openVersionSubView(v);
            return;
        }

        if (param === 'bot-versions') {
            openBotModal();
            return;
        }

        if (param.startsWith('bot-version-')) {
            var bv = param.split('bot-version-')[1];
            openBotModal(bv);
            return;
        }

        if (param === 'security') {
            openSecurityModal();
            return;
        }

        if (param === 'review') {
            openReviewModal();
            return;
        }

        if (param === 'pc-tools') {
            openPcToolsModal();
            return;
        }

        var urlParams = new URLSearchParams(query);
        if (urlParams.get('returnTo') === '4.5') {
            openVersionSubView('4.5');
            history.replaceState(null, null, window.location.pathname);
        }
    }

    // Expose helpers globally if needed
    window.openVersionsList = openVersionsList;
    window.openVersionSubView = openVersionSubView;
    window.openBotModal = openBotModal;
    window.openSecurityModal = openSecurityModal;
    window.openReviewModal = openReviewModal;
    window.openPcToolsModal = openPcToolsModal;
    window.closeAllModals = closeAllModals;
    window.handleSearchRouting = handleSearchRouting;

    window.addEventListener('load', function() {
        initNotepadInput();
        handleSearchRouting();
    });
    window.addEventListener('popstate', handleSearchRouting);

    if (document.readyState === 'complete' || document.readyState === 'interactive') {
        initNotepadInput();
        handleSearchRouting();
    }
})();

(function () {
    'use strict';
    // Freeze the page behind any open modal (CSS animations + WebGL lightning) so nothing lags.
    function sync() {
        var open = !!document.querySelector('.modal-overlay.active');
        document.documentElement.classList.toggle('modal-open', open);
    }
    function init() {
        var overlays = document.querySelectorAll('.modal-overlay');
        var mo = new MutationObserver(sync);
        for (var i = 0; i < overlays.length; i++) {
            mo.observe(overlays[i], { attributes: true, attributeFilter: ['class'] });
        }
        sync();
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();
})();

/* ==========================================================================
   PC: version lists scroll one version per mouse-wheel notch (no half-cut cards).
   - One wheel notch moves exactly one version to the top, with a smooth glide.
   - After the scroll bar is dragged / the keyboard is used, the list settles on the nearest
     version, so a card is never left cut in half at the top.
   Phones / touch screens keep their normal scrolling.
   ========================================================================== */
(function () {
    'use strict';
    var PC = window.matchMedia('(min-width: 1024px) and (hover: hover) and (pointer: fine)');

    function setup(list) {
        if (list.__stepScroll) return;
        list.__stepScroll = true;

        var raf = 0;
        var animating = false;
        var targetIdx = -1;
        var acc = 0;
        var accTimer = 0;
        var settleTimer = 0;

        function items() { return list.querySelectorAll(':scope > .version-item'); }
        function maxTop() { return Math.max(0, list.scrollHeight - list.clientHeight); }
        function posOf(idx) {
            var its = items();
            if (!its.length) return 0;
            idx = Math.max(0, Math.min(idx, its.length - 1));
            return Math.min(its[idx].offsetTop - its[0].offsetTop, maxTop());
        }
        function nearestIdx(top) {
            var its = items();
            var best = 0, bestD = Infinity;
            for (var i = 0; i < its.length; i++) {
                var d = Math.abs((its[i].offsetTop - its[0].offsetTop) - top);
                if (d < bestD) { bestD = d; best = i; }
            }
            return best;
        }
        function glideTo(to) {
            cancelAnimationFrame(raf);
            var from = list.scrollTop;
            var dist = to - from;
            if (Math.abs(dist) < 1) { list.scrollTop = to; animating = false; return; }
            var dur = 240;
            var t0 = performance.now();
            animating = true;
            var ease = function (t) { return 1 - Math.pow(1 - t, 3); };
            (function step(now) {
                var t = Math.min(1, (now - t0) / dur);
                list.scrollTop = from + dist * ease(t);
                if (t < 1) raf = requestAnimationFrame(step);
                else { list.scrollTop = to; animating = false; }
            })(t0);
        }

        list.addEventListener('wheel', function (e) {
            if (!PC.matches || e.ctrlKey || e.metaKey) return;
            if (!list.offsetParent) return; // hidden list
            if (Math.abs(e.deltaX) > Math.abs(e.deltaY)) return;
            e.preventDefault();
            e.stopPropagation();

            // one step per notch; trackpads send many small deltas, so they are summed first
            acc += e.deltaMode === 0 ? e.deltaY : e.deltaY * 40;
            clearTimeout(accTimer);
            accTimer = setTimeout(function () { acc = 0; }, 160);
            if (Math.abs(acc) < 40) return;
            var dir = acc > 0 ? 1 : -1;
            acc = 0;

            var its = items();
            if (!its.length) return;
            var cur = animating && targetIdx >= 0 ? targetIdx : nearestIdx(list.scrollTop);
            targetIdx = Math.max(0, Math.min(its.length - 1, cur + dir));
            glideTo(posOf(targetIdx));
        }, { passive: false });

        // Settle on the nearest version after other kinds of scrolling (scroll bar, keyboard)
        list.addEventListener('scroll', function () {
            if (animating || !PC.matches) return;
            clearTimeout(settleTimer);
            settleTimer = setTimeout(function () {
                if (animating || !list.offsetParent) return;
                var idx = nearestIdx(list.scrollTop);
                var to = posOf(idx);
                if (Math.abs(to - list.scrollTop) > 1) { targetIdx = idx; glideTo(to); }
            }, 140);
        }, { passive: true });
    }

    function init() {
        var lists = document.querySelectorAll('.versions-list');
        for (var i = 0; i < lists.length; i++) setup(lists[i]);
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();
})();
