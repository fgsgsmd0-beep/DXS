// Caches the intro video in the browser so it is downloaded only once (works offline too).
const CACHE = 'devyasin-video-v3';
const VIDEO = '/video.mp4';
const POSTER = '/devyasinx.jpg';

self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(CACHE)
      // Only the small poster is fetched at install. The 2.7 MB video used to be downloaded here,
      // competing with the page itself on a phone connection; the player now requests it a few seconds after load and this worker caches that response.
      .then((c) => c.add(POSTER))
      .then(() => self.skipWaiting())
      .catch(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

// Serve the video from cache, supporting Range requests (needed by <video> seeking/playback)
async function serveVideo(request) {
  const cache = await caches.open(CACHE);
  let res = await cache.match(VIDEO);
  if (!res) {
    const net = await fetch(VIDEO);
    if (net.ok && net.status === 200) cache.put(VIDEO, net.clone());
    res = net;
    if (!request.headers.get('range')) return res;
  }
  const range = request.headers.get('range');
  if (!range) return res;
  const buf = await res.arrayBuffer();
  const m = /bytes=(\d*)-(\d*)/.exec(range);
  const start = m && m[1] ? parseInt(m[1], 10) : 0;
  const end = m && m[2] ? Math.min(parseInt(m[2], 10), buf.byteLength - 1) : buf.byteLength - 1;
  return new Response(buf.slice(start, end + 1), {
    status: 206,
    statusText: 'Partial Content',
    headers: {
      'Content-Type': 'video/mp4',
      'Accept-Ranges': 'bytes',
      'Content-Length': String(end - start + 1),
      'Content-Range': `bytes ${start}-${end}/${buf.byteLength}`,
    },
  });
}

self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET' || url.origin !== self.location.origin) return;
  if (url.pathname === VIDEO) {
    e.respondWith(serveVideo(e.request).catch(() => fetch(e.request)));
  } else if (url.pathname === POSTER) {
    e.respondWith(caches.match(POSTER).then((r) => r || fetch(e.request)));
  }
});

